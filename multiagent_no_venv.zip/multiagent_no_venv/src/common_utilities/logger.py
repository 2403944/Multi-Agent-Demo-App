import json
import os
from datetime import datetime

import definitions
from src.common_utilities.configuration_loader import ConfigurationLoader

configurations = ConfigurationLoader()
LOG_DIR = os.path.join(definitions.ROOT_DIR, configurations.get_configuration("LOGS", "log_folder"))
os.makedirs(LOG_DIR, exist_ok=True)


def log_trace(claim_id: str, step: str, output: dict):
    log_path = os.path.join(LOG_DIR, f"{claim_id}.log")
    log_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "step": step,
        "output": output,
    }

    with open(log_path, "a") as log_file:
        log_file.write(json.dumps(log_entry) + "\n")
