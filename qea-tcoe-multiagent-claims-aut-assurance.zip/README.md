# QEA TCOE Multi-Agent Claims Automation & Assurance System

An intelligent, autonomous healthcare insurance claims processing system built with LangGraph, featuring dynamic agent selection, intelligent tool usage, and autonomous decision-making capabilities.

## 🎯 Overview

This system represents a cutting-edge approach to insurance claims processing, leveraging multiple autonomous agents that work collaboratively to process healthcare insurance claims with minimal human intervention. The system demonstrates advanced autonomy through intelligent agent selection, dynamic tool usage, and context-aware decision making.

## 🚀 Novel Autonomy Features

### 1. **Dynamic Agent Selection & Routing**
The system features an **autonomous supervisor agent** ([`decision_agent.py`](src/healthcare/agents/decision_agent.py)) that uses LLM-powered decision making to intelligently route claims:

- **Intelligent Routing Logic**: Analyzes claim data, document verification results, fraud scores, and confidence levels
- **LLM-Driven Decisions**: Uses structured prompts to determine whether claims should go to:
  - [`final_communication_agent.py`](src/healthcare/agents/final_communication_agent.py) for auto-approval
  - [`human_verification_agent.py`](src/healthcare/agents/human_verification_agent.py) for manual review
- **Context-Aware Processing**: Makes routing decisions based on comprehensive claim analysis including document status, fraud indicators, and claim amounts

### 2. **Autonomous Tool Selection & Usage**
The [`document_agent.py`](src/healthcare/agents/document_agent.py) demonstrates sophisticated tool calling capabilities:

- **Conditional Tool Invocation**: Automatically calls [`check_doc_integrity`](src/healthcare/tools/document_integrity_tool.py) for all claims
- **Failure-Driven Tool Selection**: When document integrity fails, the LLM autonomously decides to invoke [`integrity_investigator`](src/healthcare/tools/integrity_investigator_tool.py) for detailed analysis
- **Tool Chain Orchestration**: Manages complex tool calling sequences based on intermediate results

### 3. **Multi-Agent Fraud Detection System**
The [`fraud_checker_agents.py`](src/healthcare/agents/fraud_checker_agents.py) implements specialized fraud detection agents:

- **Domain-Specific Agents**: Multiple fraud checkers for different aspects:
  - `fraud_duplicate_claim_checker`: Detects duplicate claims
  - `fraud_inconsistency_checker`: Identifies data inconsistencies  
  - `fraud_provider_verification_checker`: Validates provider authenticity
  - `fraud_service_reasonability_checker`: Assesses medical service reasonableness
- **Adaptive Processing**: Each agent can process existing notes or perform fresh LLM analysis
- **Risk-Based Scoring**: Autonomous fraud scoring with automatic escalation thresholds

### 4. **Intelligent Workflow Orchestration**
The [`healthcare_workflow.py`](src/healthcare/workflows/healthcare_workflow.py) creates a dynamic processing pipeline:

- **Conditional Flow Control**: Uses `decide_fraud()` function to automatically route claims based on document verification results
- **State-Driven Processing**: Maintains comprehensive claim state across all agents
- **Autonomous Escalation**: Automatically determines when human intervention is required

### 5. **Claim Classification & Domain Adaptation**
The [`supervisor_agent.py`](src/healthcare/agents/supervisors/supervisor_agent.py) provides:

- **Intelligent Classification**: Automatically categorizes claims into 'Auto_Insurance', 'health', or 'base' domains
- **Context-Aware Analysis**: Uses claim details and descriptions for accurate classification
- **Fallback Mechanisms**: Robust error handling with intelligent defaults

## 🏗️ System Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Entry Point   │───▶│  Document Agent  │───▶│ Fraud Detection │
│   (executor.py) │    │                  │    │    Agents       │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                               │                         │
                               ▼                         ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Human Review    │◀───│ Decision Agent   │◀───│ Summarizer      │
│    Agent        │    │  (Supervisor)    │    │    Agent        │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                               │
                               ▼
                    ┌─────────────────┐
                    │ Final Comm      │
                    │    Agent        │
                    └─────────────────┘
```

## 🔧 Core Components

### Autonomous Agents
- **Document Verification**: [`health_document_agent()`](src/healthcare/agents/document_agent.py:13) - Autonomous document validation with tool integration
- **Decision Supervisor**: [`decision_agent()`](src/healthcare/agents/decision_agent.py:11) - LLM-powered routing decisions
- **Fraud Detection**: Multiple specialized fraud checker agents with autonomous analysis
- **Summarization**: [`get_summarizer_agent()`](src/healthcare/agents/summarizer_agent.py:20) - Intelligent claim summarization
- **Final Processing**: Autonomous claim approval and human escalation agents

### Intelligent Tools
- **Document Integrity**: [`check_doc_integrity()`](src/healthcare/tools/document_integrity_tool.py:6) - Simulated document validation
- **Failure Investigation**: [`integrity_investigator()`](src/healthcare/tools/integrity_investigator_tool.py:6) - Deep dive analysis for failed checks

### Infrastructure
- **LLM Management**: [`LLMManager`](src/common_layers/llm_layer/llm_manager.py:9) - Azure OpenAI integration
- **State Management**: [`GraphState`](src/healthcare/state.py:5) - Comprehensive state tracking
- **Logging**: [`log_trace()`](src/common_utilities/logger.py:13) - Detailed execution tracing

## 📁 Developer Guide - File Structure & Responsibilities

### Core Execution
```
src/healthcare/
├── executor.py                    # Main entry point, workflow orchestration
└── workflows/
    └── healthcare_workflow.py     # LangGraph workflow definition, agent coordination
```

### Autonomous Agents
```
src/healthcare/agents/
├── decision_agent.py             # 🎯 SUPERVISOR - LLM-powered agent routing
├── document_agent.py             # 📄 Document verification with tool calling
├── fraud_checker_agents.py       # 🔍 Multi-agent fraud detection system
├── summarizer_agent.py           # 📝 Claim summarization agent
├── final_communication_agent.py  # ✅ Auto-approval processing
├── human_verification_agent.py   # 👨‍💼 Manual review escalation
├── claim_decision_agent.py       # 🎯 Legacy decision maker
└── supervisors/
    └── supervisor_agent.py       # 🏷️ Claim classification agent
```

### Intelligent Tools
```
src/healthcare/tools/
├── __init__.py                   # Tool exports
├── document_integrity_tool.py    # 🛡️ Document authenticity checking
└── integrity_investigator_tool.py # 🔬 Deep failure analysis tool
```

### Infrastructure & Utilities
```
src/common_layers/
└── llm_layer/
    └── llm_manager.py            # 🤖 Azure OpenAI client management

src/common_utilities/
├── configuration_loader.py       # ⚙️ Configuration management
└── logger.py                     # 📊 Execution tracing and debugging

configurations/
└── project_configurations.ini    # 🔧 System configuration

src/healthcare/
├── state.py                      # 📋 Comprehensive state management
└── prompts/                      # 💬 Agent prompt templates
```

## 🔑 Key Autonomy Patterns

### 1. LLM-Driven Agent Selection
```python
# From decision_agent.py
routing_decision = llm.invoke([HumanMessage(content=structured_prompt)])
if routing_decision == "final_communication":
    result = final_communication_agent()(state)
else:
    result = human_verification_agent()(state)
```

### 2. Conditional Tool Calling
```python
# From document_agent.py
if response.choices[0].message.tool_calls:
    # LLM autonomously decided to call integrity_investigator
    investigation_result = integrity_investigator(claim_id, failure_details)
```

### 3. Dynamic Workflow Routing
```python
# From healthcare_workflow.py
builder.add_conditional_edges('DocumentVerifier', decide_fraud, {
    "FraudDetector": "FraudDetector",
    "Summarizer": "Summarizer",
})
```

## 🚀 Getting Started

### Prerequisites
- Python 3.8+
- Azure OpenAI API access
- Required packages: `pip install -r requirements.txt`

### Environment Setup
1. Create `.env` file in your home directory under `text-gen-home/`:
```env
AZURE_API_KEY=your_azure_api_key
AZURE_API_VERSION=2024-02-15-preview
AZURE_OPENAI_LLM_DEPLOYMENT=your_deployment_name
AZURE_API_BASE=https://your-resource.openai.azure.com/
```

### Running the System
```bash
# Execute healthcare claims processing
python src/healthcare/executor.py
```

### Key Configuration
- **Logging**: Configured in [`project_configurations.ini`](configurations/project_configurations.ini)
- **LLM Settings**: Managed via environment variables
- **Workflow Parameters**: Defined in [`healthcare_workflow.py`](src/healthcare/workflows/healthcare_workflow.py)

## 📊 Monitoring & Observability

The system provides comprehensive logging through the [`log_trace()`](src/common_utilities/logger.py:13) function:

- **Agent-Level Tracing**: Each agent logs start, processing steps, and completion
- **Tool Usage Tracking**: Detailed logging of tool calls and results  
- **Decision Audit Trail**: Full record of autonomous decisions and reasoning
- **Performance Metrics**: Execution times and confidence scores
- **Error Handling**: Comprehensive error logging with fallback mechanisms

## 🎯 Autonomy Highlights

### What Makes This System Autonomous:

1. **Zero Human Configuration**: Agents automatically adapt to different claim types and scenarios
2. **Self-Healing Workflows**: Robust error handling with intelligent fallbacks
3. **Context-Aware Processing**: Decisions based on accumulated state and intermediate results
4. **Dynamic Tool Selection**: Tools are called based on runtime analysis, not pre-programmed rules
5. **Intelligent Escalation**: Automatic determination of when human intervention is needed
6. **Adaptive Risk Assessment**: Fraud detection that adjusts based on claim characteristics

### Potential Extensions:

- **Learning Mechanisms**: Integration with feedback loops for continuous improvement
- **Multi-Domain Support**: Extension to auto, property, and life insurance
- **Real-Time Adaptation**: Dynamic agent behavior based on processing patterns
- **Advanced Tool Integration**: Connection to external APIs and databases
- **Regulatory Compliance**: Automated compliance checking and reporting

## 🤝 Contributing

This system is designed for extensibility. Key extension points:

- Add new agents in [`src/healthcare/agents/`](src/healthcare/agents/)
- Create new tools in [`src/healthcare/tools/`](src/healthcare/tools/)
- Extend workflows in [`src/healthcare/workflows/`](src/healthcare/workflows/)
- Add domain-specific prompts in [`src/healthcare/prompts/`](src/healthcare/prompts/)

## 📜 License

This project is part of the QEA TCOE initiative for advanced insurance automation and assurance systems.

---
*Built with ❤️ by the QEA TCOE team - Pioneering autonomous insurance claim processing*