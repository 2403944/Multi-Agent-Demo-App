import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_community.chat_models import AzureChatOpenAI
from openai import AzureOpenAI


class LLMManager:
    def __init__(self):
        self.env_load_status = load_dotenv()

    def get_llm(self):
        if not self.env_load_status:
            raise EnvironmentError("Failed to load environment variables from .env file")
        return AzureChatOpenAI(
            openai_api_key=os.getenv("AZURE_API_KEY"),
            openai_api_version=os.getenv("AZURE_API_VERSION"),
            deployment_name=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
            azure_endpoint=os.getenv("AZURE_API_BASE"),
        )

    def get_non_chat_client(self):
        if not self.env_load_status:
            raise EnvironmentError("Failed to load environment variables from .env file")
        return AzureOpenAI(
            api_key=os.getenv("AZURE_API_KEY"),
            api_version=os.getenv("AZURE_API_VERSION"),
            azure_deployment=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
            azure_endpoint=os.getenv("AZURE_API_BASE"),
        )
