import configparser
import os

import definitions


class ConfigurationLoader(object):

    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read(os.path.join(definitions.ROOT_DIR, "configurations", "project_configurations.ini"))

    def get_configuration(self, section: str, key: str) -> str:
        return self.config.get(section, key)
