from src.healthcare.agents.supervisors.supervisor_agent import *
from src.common_utilities.logger import log_trace
from src.healthcare.agents.fraud_checker_agents import *
from src.healthcare.state import GraphState
import re
from langchain.schema import HumanMessage

from typing import Dict, Any

from langsmith import traceable

@traceable(name="DecisionMakerAgent", run_type="chain") #chain bcoz This agent is not a tool (it’s not a small deterministic helper). It’s also not a raw LLM call (no direct model invocation here). It’s an orchestrator that makes a decision based on multiple inputs.
def decision_maker_agent(state: GraphState) -> Dict[str, Any]:
    print(f"\n🎯 === CLAIM DECISION MAKER AGENT STARTED ===")
    claim_id = state.claim_id or f"CLM_{state.policy_id}"
    print(f"🆔 Claim ID: {claim_id}")
    print(f"📋 Policy ID: {state.policy_id}")
    
    log_trace(
        claim_id=claim_id,
        step="decision_maker_agent_start",
        output={
            "agent": "decision_maker_agent",
            "claim_id": claim_id,
            "policy_id": state.policy_id,
            "state_keys": list(state.__dict__.keys()) if hasattr(state, '__dict__') else "unknown"
        }
    )

    doc_ok = state.doc_status == "approved"
    fraud_score = state.fraud_score
    reason = state.summary or ""
    amount = state.claim_record.get("claim_amount", 0.0) if state.claim_record else 0.0
    
    print(f"📊 Decision Inputs Analysis:")
    print(f"   Document Status: {state.doc_status} -> OK: {doc_ok}")
    print(f"   Fraud Score: {fraud_score}")
    print(f"   Summary/Reason: {reason}")
    print(f"   Claim Amount: ${amount}")
    
    log_trace(
        claim_id=claim_id,
        step="decision_maker_agent_inputs",
        output={
            "doc_status": state.doc_status,
            "doc_ok": doc_ok,
            "fraud_score": fraud_score,
            "summary": reason,
            "claim_amount": amount
        }
    )
    
    # Decision logic with detailed logging
    if not doc_ok:
        decision, reason, final_amount = (
            "rejected",
            reason if reason else "Document verification failed.",
            0.0,
        )
        print(f"❌ DECISION: REJECTED (Document verification failed)")
        print(f"   Reason: {reason}")
        print(f"   Final Amount: ${final_amount}")
    elif fraud_score == 0.0:
        decision, reason, final_amount = "approved", reason, amount
        print(f"✅ DECISION: APPROVED (No fraud detected)")
        print(f"   Reason: {reason}")
        print(f"   Final Amount: ${final_amount}")
    else:
        decision, reason, final_amount = "rejected", reason, 0.0
        print(f"❌ DECISION: REJECTED (Fraud detected)")
        print(f"   Fraud Score: {fraud_score}")
        print(f"   Reason: {reason}")
        print(f"   Final Amount: ${final_amount}")
    
    log_trace(
        claim_id=claim_id,
        step="decision_maker_agent_logic",
        output={
            "decision_logic": "document_and_fraud_based",
            "doc_ok": doc_ok,
            "fraud_score": fraud_score,
            "decision": decision,
            "final_amount": final_amount,
            "decision_reason": reason
        }
    )

    output = {
        "decision": decision,
        "reason": reason,
        "final_amount": final_amount,
        "confidence_score": 0.9,  # Assuming a default confidence score
    }
    
    print(f"📋 Final Decision Output:")
    print(f"   Decision: {decision}")
    print(f"   Reason: {reason}")
    print(f"   Final Amount: ${final_amount}")
    print(f"   Confidence Score: {output['confidence_score']}")
    
    log_trace(
        claim_id=claim_id,
        step="decision_maker_agent_result",
        output=output,
    )
    
    print(f"🏁 Claim Decision Maker Agent Completed")
    print(f"🎯 === CLAIM DECISION MAKER AGENT FINISHED ===\n")
    
    log_trace(
        claim_id=claim_id,
        step="decision_maker_agent_complete",
        output={
            "agent_completed": True,
            "final_decision": decision,
            "final_amount": final_amount,
            "confidence": output['confidence_score']
        }
    )
    
    return output
