import json
from typing import Dict
from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from src.common_layers.llm_layer.llm_manager import LLMManager
from src.common_utilities.logger import log_trace
from src.healthcare.agents.final_communication_agent import final_communication_agent
from src.healthcare.agents.human_verification_agent import human_verification_agent

from langsmith import traceable


def decision_agent() -> Runnable:
    """
    Supervisor decision agent that uses LLM to decide between
    final_communication_agent or human_verification_agent based on claim analysis.
    """

    def run_supervisor_agent(state: Dict) -> Dict:
        print(f"\n⚖️  === DECISION SUPERVISOR AGENT STARTED ===")
        print(f"📄 Input State Keys: {list(state.keys())}")

        # Extract information from state for analysis
        raw_doc_result = state.get("document_check_result")
        summary = state.get("summary", "")
        claim_record = state.get("claim_record", {})

        print(f"📋 Raw Document Result Available: {bool(raw_doc_result)}")
        print(f"📋 Summary Available: {bool(summary)}")
        print(f"📋 Claim Record Available: {bool(claim_record)}")

        try:
            doc_result = json.loads(raw_doc_result) if raw_doc_result else {}
            print(f"doc_result : \n {doc_result}")
            print(f"✅ Document result parsed successfully")
        except (json.JSONDecodeError, TypeError) as e:
            print(f"❌ Failed to parse document result: {e}")
            doc_result = {}

        doc_status = doc_result.get("status", "failed") if doc_result else "failed"
        claim_id = (
            doc_result.get("claim_id", state.get("policy_id", "unknown"))
            if doc_result
            else state.get("policy_id", "unknown")
        )
        doc_reason = (
            doc_result.get("reason", "Document verification status unclear")
            if doc_result
            else "Document verification status unclear"
        )
        doc_confidence = doc_result.get("confidence", 0.5) if doc_result else 0.5

        # Extract additional context from claim record
        claim_amount = claim_record.get("claim_amount", 0) if claim_record else 0
        claim_notes = claim_record.get("notes", []) if claim_record else []

        print(f"📊 Decision Input Analysis:")
        print(f"   Claim ID: {claim_id}")
        print(f"   Document Status: {doc_status}")
        print(f"   Document Confidence: {doc_confidence}")
        print(f"   Document Reason: {doc_reason}")
        print(f"   Claim Amount: ${claim_amount:,}")
        print(f"   Notes Count: {len(claim_notes)}")
        print(f"   Summary Length: {len(summary)} chars")

        log_trace(
            claim_id=claim_id,
            step="decision_supervisor_agent_start",
            output={
                "agent": "decision_supervisor_agent",
                "input_keys": list(state.keys()),
                "doc_status": doc_status,
                "doc_confidence": doc_confidence,
                "doc_result_available": bool(doc_result),
                "claim_id": claim_id,
                "claim_amount": claim_amount,
                "notes_count": len(claim_notes)
            }
        )

        # Prepare notes text
        notes_text = "\n".join(claim_notes) if claim_notes else "No notes available"

        # Create structured prompt for routing decision
        prompt = f"""You are an expert insurance claims supervisor agent. 
        Analyze the following claim information and decide which agent should handle the next step.

CLAIM DETAILS:
- Claim ID: {claim_id}
- Claim Amount: ${claim_amount:,}
- Document Verification Status: {doc_status}
- Document Verification Confidence: {doc_confidence}
- Document Verification Reason: {doc_reason}

SUMMARY:
{summary}

CLAIM NOTES:
{notes_text}

ROUTING OPTIONS:
1. "final_communication" - Choose this if the claim looks good on all aspects and can be auto-approved.
2. "human_verification" - Choose this if anything is unclear, inconsistent, or requires manual review.
3. "not_approved" - Choose this if the claim clearly fails and should be automatically rejected.

CRITERIA FOR FINAL COMMUNICATION (Auto-Approval):
- Document verification status is "passed"
- Confidence score is high (>= 0.7)
- No fraud indicators in notes
- Reasonable claim amount for the policy
- All checks passed

CRITERIA FOR HUMAN VERIFICATION:
- Document verification failed or is unclear
- Confidence score is moderate (>0.3 and <0.7)
- Some red flags or inconsistencies in notes
- Claim needs human judgment

CRITERIA FOR NOT APPROVED (Automatic Rejection):
- Document verification failed with strong evidence
- Confidence score is low (<= 0.3)
- Fraud indicators present
- Missing, forged, or non-compliant documents
- Claim amount is clearly unjustified

If the confidence score is moderate (between 0.3 and 0.7) and there are some fraud indicators but no definitive proof of fraud, 
then choose "human_verification". Only choose "not_approved" if confidence is low (< 0.3) AND strong fraud evidence exists.

Respond with ONLY a JSON object in this exact format:
DO NOT ADD '''json or anything else before or after the json object.

Exact output format required : 
{{
    "routing_decision": "final_communication" or "human_verification" or "not_approved"
    "reasoning": "brief explanation of why this routing was chosen",
    "confidence": 0.0 to 1.0
}}

"""

        print(f"🔄 Making LLM routing decision...")
        print(f"📝 Prompt length: {len(prompt)} chars")

        log_trace(
            claim_id=claim_id,
            step="decision_supervisor_agent_llm_call",
            output={
                "prompt_length": len(prompt),
                "action": "llm_routing_decision",
                "doc_status": doc_status,
                "doc_confidence": doc_confidence
            }
        )

        # Get LLM and make routing decision
        llm_manager = LLMManager()
        llm = llm_manager.get_llm()

        response = llm.invoke(
            [HumanMessage(content=prompt)],
            config={"run_name": "DecisionAgent"}
        )
        print(f"✅ LLM Response Received: {response.content}")

        # Parse the JSON response
        try:
            decision_json = json.loads(response.content.strip())
            routing_decision = decision_json.get("routing_decision", "human_verification")
            reasoning = decision_json.get("reasoning", "No reasoning provided")
            llm_confidence = decision_json.get("confidence", 0.5)

            print(f"📋 Parsed LLM Decision:")
            print(f"   Routing: {routing_decision}")
            print(f"   Reasoning: {reasoning}")
            print(f"   LLM Confidence: {llm_confidence}")

        except (json.JSONDecodeError, AttributeError) as e:
            print(f"❌ Failed to parse LLM response as JSON: {e}")
            print(f"Raw response: {response.content}")
            # Default to human verification if parsing fails
            routing_decision = "human_verification"
            reasoning = "Failed to parse LLM response, defaulting to human verification"
            llm_confidence = 0.5

        # Validate routing decision
        if routing_decision not in ["final_communication", "human_verification", "not_approved"]:
            print(f"⚠️ Invalid routing decision '{routing_decision}', defaulting to 'human_verification'")
            routing_decision = "human_verification"
            reasoning = f"Invalid routing decision, defaulted to human verification"

        log_trace(
            claim_id=claim_id,
            step="decision_supervisor_agent_routing_decision",
            output={
                "llm_response": response.content,
                "routing_decision": routing_decision,
                "reasoning": reasoning,
                "llm_confidence": llm_confidence,
                "parsing_successful": True
            }
        )

        # Execute the routing decision
        if routing_decision == "final_communication":
            print(f"✅ SUPERVISOR DECISION: ROUTE TO FINAL COMMUNICATION")
            print(f"   Reasoning: {reasoning}")
            result = final_communication_agent()(state)
        elif routing_decision == "not_approved":
            print(f"❌ SUPERVISOR DECISION: CLAIM REJECTED")
            print(f"   Reasoning: {reasoning}")
            result = {
                "status": "rejected",
                "reason": reasoning,
                "claim_id": claim_id,
                "handled_by": "decision_supervisor_agent"
            }
            state.update({
                "workflow_status": "Not Approved",
                "reason": reasoning,
                "handled_by": "decision_supervisor_agent",
                "decision": "rejected"
            })
            return state
        else:
            print(f"⚠️ SUPERVISOR DECISION: ROUTE TO HUMAN VERIFICATION")
            print(f"   Reasoning: {reasoning}")
            result = human_verification_agent()(state)

        # print("*************************************************************")
        # print(f"SUPERVISOR DECISION Result : {result}")
        # print("*************************************************************")

        # Add supervisor metadata to the result
        supervisor_result = {
            "timestamp": "2025-06-26T16:45:00",
            "claim_id": claim_id,
            "step": "decision_supervisor_agent",
            "routing_decision": routing_decision,
            "reasoning": reasoning,
            "llm_confidence": llm_confidence,
            "llm_response": response.content,
            "supervised_by": "decision_supervisor_agent"
        }

        '''
        how confident the LLM is about its decision to route the claim either to:
        "final_communication" (auto-approval)
        or "human_verification" (manual review).
        '''

        print(f"📋 Supervisor Decision Result:")
        print(f"   Routing Decision: {routing_decision}")
        print(f"   Reasoning: {reasoning}")
        print(f"   LLM Confidence: {llm_confidence}")
        print(f"   Supervised By: decision_supervisor_agent")

        log_trace(
            claim_id=claim_id,
            step="decision_supervisor_agent_result",
            output=supervisor_result
        )

        # Merge supervisor metadata with agent result
        result["supervisor_result"] = supervisor_result
        result["routing_decision"] = routing_decision
        result["supervisor_reasoning"] = reasoning
        result["supervisor_confidence"] = llm_confidence

        print(f"🏁 Decision Supervisor Agent Completed")
        print(f"   Final Output Keys: {list(result.keys())}")
        print(f"   Routing Decision: {routing_decision}")
        print(f"⚖️  === DECISION SUPERVISOR AGENT FINISHED ===\n")

        log_trace(
            claim_id=claim_id,
            step="decision_supervisor_agent_complete",
            output={
                "agent_completed": True,
                "routing_decision": routing_decision,
                "output_keys": list(result.keys()),
                "llm_confidence": llm_confidence
            }
        )

        print("*************************************************************")
        print(f"SUPERVISOR DECISION Result : {result}")
        print("*************************************************************")

        # # Update state with supervisor result and downstream agent result
        # state.update(result)
        # state.update({
        #     "supervisor_result": supervisor_result,
        #     "routing_decision": routing_decision,
        #     "supervisor_reasoning": reasoning,
        #     "supervisor_confidence": llm_confidence
        # })
        #
        # print(f"🏁 Decision Supervisor Agent Completed")
        # print(f"   Final State Keys: {list(state.keys())}")
        # print(f"   Routing Decision: {routing_decision}")
        # print(f"⚖️  === DECISION SUPERVISOR AGENT FINISHED ===\n")
        #
        # return state

        return result

    return run_supervisor_agent
