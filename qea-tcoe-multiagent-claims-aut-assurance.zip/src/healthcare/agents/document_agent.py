import os
from datetime import datetime, timedelta

from langchain_community.chat_models import AzureChatOpenAI
from langchain_core.runnables import Runnable
from ragas.llms.base import LangchainLLMWrapper

from src.common_layers.llm_layer.llm_manager import LLMManager
from src.common_utilities.logger import log_trace
from src.healthcare.tools import check_doc_integrity, integrity_investigator


def health_document_agent() -> Runnable:
    def run_agent(input: dict) -> dict:
        claim_record = input.get("claim_record", {})
        policy_id = input.get("policy_id", "unknown")

        # Log agent invocation
        print(f"\n🏥 === HEALTH DOCUMENT AGENT STARTED ===")
        print(f"📋 Policy ID: {policy_id}")
        print(f"📄 Input Keys: {list(input.keys())}")

        log_trace(
            claim_id=policy_id,
            step="health_document_agent_start",
            output={
                "agent": "health_document_agent",
                "input_keys": list(input.keys()),
                "policy_id": policy_id,
                "claim_record_available": bool(claim_record)
            }
        )
        import json
        claim_record_str = json.dumps(claim_record, indent=2)
        print(f"📊 Claim Record Structure: {len(claim_record)} fields")

        rules = [
            {
                "submitted_documents_completeness": "All required documents, such as medical bills, medical records, and proof of payment, must be provided."
            },
            {
                "authenticity_check": "Submitted documents must be genuine and free from tampering or forgery."
            },
            {
                "duplicate_document_check": "Ensure that no duplicate bills or records are submitted for the same service."
            },
            {
                "provider_details_verification": "Verify that provider information (e.g., hospital or surgeon) on submitted documents matches official records."
            },
            {
                "service_date_verification": "Confirm that the service dates on documents are clearly stated and align with the claimed event."
            },
        ]
        rules_str = json.dumps(rules, indent=2)

        # Log rules being applied
        print(f"📋 Document Verification Rules ({len(rules)} rules):")
        for i, rule in enumerate(rules, 1):
            rule_name = list(rule.keys())[0]
            print(f"  {i}. {rule_name}")

        log_trace(
            claim_id=policy_id,
            step="health_document_agent_rules",
            output={
                "rules_count": len(rules),
                "rules_applied": [list(rule.keys())[0] for rule in rules]
            }
        )

        # Call document integrity tool before LLM analysis
        print(f"🔧 Invoking document integrity tool...")
        integrity_result = check_doc_integrity(
            claim_id=policy_id,
            document_data=claim_record
        )
        
        print(f"🔧 Tool Result: {integrity_result['integrity_status']}")
        print(f"   Integrity Confidence: {integrity_result['integrity_confidence']}")
        print(f"   Tool Reason: {integrity_result['integrity_reason']}")

        log_trace(
            claim_id=policy_id,
            step="health_document_agent_tool_call",
            output={
                "tool_name": "check_doc_integrity",
                "tool_result": integrity_result,
                "integrity_status": integrity_result['integrity_status']
            }
        )

        # Define tool schema for LLM tool calling
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "integrity_investigator",
                    "description": (
                        "Investigate integrity failures when document integrity check fails. "
                        "Use this tool when document integrity status is 'failed' to get detailed analysis of the failure reasons."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "claim_id": {
                                "type": "string",
                                "description": "The claim ID being processed"
                            },
                            "integrity_failure_details": {
                                "type": "string",
                                "description": "Details about why the integrity check failed"
                            },
                            "document_tool_result": {
                                "type": "string",
                                "description": "Previous tool output or result relevant to the document integrity"
                            }
                        },
                        "required": ["claim_id", "integrity_failure_details", "document_tool_result"]
                    }
                }
            }
        ]

        azure_client = LLMManager().get_non_chat_client()
        print(f"🤖 LLM Client initialized for document verification with tool calling")

        messages = [
            {
                "role": "user",
                "content": f"""You are an AI assistant tasked with validating an insurance claim for the document_verification_agent based on provided claim details and predefined rules. You will receive:
            1. A claim record with fields: `name`, `policy_id`, `policy_id`,," `policy_start`,," `policy_end`, `claim_type`, `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
            2. Provided Rules for the document_verification_agent for the claim type 'Health Insurance (Major Medical Plan)').
            3. Document integrity tool result that checks document authenticity and completeness.

            **IMPORTANT**: You have access to a tool called `integrity_investigator`. If the document integrity status is "failed", you MUST use this tool to investigate the failure before providing your final response.
            Make sure to pass detailed information from the previous tool results and claim input notes to this tool in "integrity_failure_details" , so that it will be able to provide clear analysis.
            Also pass the result/output from 'check_doc_integrity' tool to parameter 'document_tool_result' in 'integrity_investigator' tool.
            
            Input to integrity_investigator tool : 
            {{
              "claim_id": "some_claim_id",
              "integrity_failure_details": "details about failure",
              "document_tool_result": "previous tool output as string"
            }}

            Your task is to:
            - Validate the claim record against the provided rules for the document_verification.
            - Consider the document integrity tool result in your analysis.
            - **If integrity status is "failed", use the integrity_investigator tool to get detailed failure analysis.**
            - Check the `notes` for explicit rule validations (e.g., "document_verification_agent: description").
            - For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields (e.g., check `accident_date` against `policy_start` and `policy_end` for `service_date_verification`).
            - If any rule fails OR if document integrity failed, the agent's status is "failed". All rules must pass AND integrity must pass for the status to be "passed".
            - Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
                - Use (greater than 0.8) for a rule explicitly validated in notes.
                - Use (between 0.2 and 0.8) for inferred validations based on fields.
                - Use (0.2 or below) for rules requiring external data with no explicit note.
                - Factor in the integrity tool confidence in your overall confidence.
                - Adjust the final confidence score up or down based on the document integrity and integrity_investigator tools outcomes.
            - After using tools (if needed), output a JSON result with the following format, with no additional text:

            {{
                "timestamp": "2025-06-26T16:45:00.00",
                "claim_id": "{policy_id}",
                "step": "document_verification",
                "status": "passed or failed",
                "reason": "explanation",
                "confidence": 0.0
            }}

            **Input Data:**

            Claim Record:
            {claim_record_str}

            Rules for the document_verification (Claim Type 'Health Insurance (Major Medical Plan)')'):
            {rules_str}

            Document Integrity Tool Result:
            Status: {integrity_result['integrity_status']}
            Reason: {integrity_result['integrity_reason']}
            Confidence: {integrity_result['integrity_confidence']}

            **Instructions:**
            1. For the document_verification:
                - FIRST, consider the document integrity result. If integrity failed, USE THE integrity_investigator TOOL to get detailed analysis.
                - Check the `notes` for explicit rule validations.
                - For rules not in `notes`, infer compliance based on fields. For example:
                    - For `service_date_verification`, check if `accident_date` falls between `policy_start` and `policy_end`.
                    - For rules requiring external data (e.g., `provider_details_verification`), use notes or assume partial compliance with lower confidence if no note exists.
                - If any rule fails OR if document integrity failed, the status is "failed". All rules must pass AND integrity must pass for "passed".
                - Factor the integrity tool confidence and any investigation results into your overall confidence score.
            2. Use tools as needed, then output the result in the specified JSON format.
            """,
            },
        ]

        # Log LLM call
        print(f"🔄 Making LLM call for document verification with tool support...")
        log_trace(
            claim_id=policy_id,
            step="health_document_agent_llm_call",
            output={
                "model": os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
                "prompt_length": len(messages[0]["content"]),
                "action": "document_verification_analysis",
                "tools_available": ["integrity_investigator"],
                "integrity_status": integrity_result['integrity_status']
            }
        )

        # Initial LLM call with tool support
        response = azure_client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
            messages=messages,
            tools=tools,
            tool_choice="auto"
        )

        investigation_result = None
        
        # Handle tool calls if LLM requests them
        if response.choices[0].message.tool_calls:
            print(f"🔧 LLM requested tool call: {response.choices[0].message.tool_calls[0].function.name}")
            
            # Add the assistant's message with tool calls to conversation
            messages.append({
                "role": "assistant",
                "content": response.choices[0].message.content,
                "tool_calls": [
                    {
                        "id": tool_call.id,
                        "type": "function",
                        "function": {
                            "name": tool_call.function.name,
                            "arguments": tool_call.function.arguments
                        }
                    } for tool_call in response.choices[0].message.tool_calls
                ]
            })
            
            # Process each tool call
            for tool_call in response.choices[0].message.tool_calls:
                if tool_call.function.name == "integrity_investigator":
                    print(f"🔧 Executing integrity_investigator tool...")
                    
                    # Parse arguments
                    import json
                    args = json.loads(tool_call.function.arguments)
                    
                    # Call the tool
                    investigation_result = integrity_investigator(
                        claim_id=args.get("claim_id", policy_id),
                        integrity_failure_details=args.get("integrity_failure_details",integrity_result['integrity_reason']),
                        document_tool_result=args.get("document_tool_result", json.dumps(integrity_result))
                    )

                    print(f"✅ Tool execution completed")
                    
                    # Add tool result to conversation
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(investigation_result)
                    })
            
            # Make follow-up call to get final response
            print(f"🔄 Making follow-up LLM call with tool results...")
            response = azure_client.chat.completions.create(
                model=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
                messages=messages
            )

        print(f"\n✅ LLM Response Received (Length: {len(response.choices[0].message.content)} chars)")
        print(f"📝 Raw Response:\n{response.choices[0].message.content}")

        response_content = (
            response.choices[0]
            .message.content.strip()
            .replace("```json", "")
            .replace("```", "")
        )

        try:
            result = json.loads(response_content)
            print(f"✅ LLM Response Parsed Successfully")
            print(f"📊 Verification Result:")
            print(f"   Status: {result.get('status', 'unknown')}")
            print(f"   Confidence: {result.get('confidence', 'unknown')}")
            print(f"   Reason: {result.get('reason', 'No reason provided')}")

            log_trace(
                claim_id=policy_id,
                step="health_document_agent_result",
                output={
                    "status": result.get('status'),
                    "confidence": result.get('confidence'),
                    "reason": result.get('reason'),
                    "claim_id": result.get('claim_id'),
                    "step": result.get('step'),
                    "parsing_successful": True
                }
            )
        except json.JSONDecodeError as e:
            print(f"❌ Failed to parse LLM response as JSON: {e}")
            print(f"📄 Raw response: {response_content}")
            result = {
                "status": "failed",
                "reason": f"JSON parsing error: {str(e)}",
                "confidence": 0.0,
                "claim_id": policy_id,
                "step": "document_verification"
            }

            log_trace(
                claim_id=policy_id,
                step="health_document_agent_error",
                output={
                    "error": str(e),
                    "raw_response": response_content,
                    "parsing_successful": False,
                    "integrity_tool_result": integrity_result
                }
            )

        single_input_for_ragas = {
            "user_input": messages[0]["content"],
            "response": str(result),
        }

        print(f"🏁 Health Document Agent Completed")
        print(f"   Final Status: {result.get('status', 'unknown')}")
        print(f"🏥 === HEALTH DOCUMENT AGENT FINISHED ===\n")

        log_trace(
            claim_id=policy_id,
            step="health_document_agent_complete",
            output={
                "final_status": result.get('status'),
                "confidence": result.get('confidence'),
                "agent_completed": True,
                "output_keys": ["document_check_result", "input", "integrity_tool_result"],
                "integrity_tool_result": integrity_result
            }
        )
        return {
            "document_check_result": response_content,
            "input": input,
            "integrity_tool_result": integrity_result,
            "investigation_result": investigation_result
        }

    return run_agent
