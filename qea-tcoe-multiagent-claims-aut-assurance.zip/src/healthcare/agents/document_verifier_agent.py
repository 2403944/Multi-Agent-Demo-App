from datetime import datetime
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import HumanMessage
import json

from src.common_utilities.logger import log_trace
from src.healthcare.prompts import document_verifier_agent_prompt
from src.healthcare.state import GraphState


def document_verifier_agent(llm) -> RunnableLambda:
    def run(state: GraphState):
        print(f"\n📋 === DOCUMENT VERIFIER AGENT STARTED ===")

        state_data = state.dict()  # type: ignore
        claim_record = state_data.get("claim_record") or {}
        rules = state_data.get("rules", [])
        policy_id = claim_record.get("policy_id", state.policy_id)
        identifier = state_data.get("identifier", "unknown")  # ✅ Extract identifier
        claim_id = f"CLM_{policy_id}"
        is_valid_claim = state_data.get("is_valid_claim", False)
        reason = state_data.get("reason", "")

        print(f"🆔 Claim ID: {claim_id}")
        print(f"🆔 Identifier: {identifier}")  # ✅ Log identifier
        print(f"📋 Policy ID: {policy_id}")
        print(f"✅ Is Valid Claim: {is_valid_claim}")
        print(f"📄 Claim Record Fields: {len(claim_record)} fields")
        print(f"📏 Rules Count: {len(rules)}")
        print(f"💬 Reason: {reason}")

        log_trace(
            claim_id,
            "document_verifier_agent_input",
            {
                "state": state_data,
                "identifier": identifier,  # ✅ Include identifier
                "is_valid_claim": is_valid_claim,
                "rules": rules,
                "reason": reason,
                "claim_record_fields": len(claim_record),
                "policy_id": policy_id
            },
        )

        # Validate claim_record completeness
        print(f"🔍 Validating claim record completeness...")
        required_fields = [
            "name", "policy_id", "policy_start", "policy_end",
            "claim_type", "accident_date", "claim_amount"
        ]
        missing_fields = [field for field in required_fields if not claim_record.get(field)]

        print(f"📋 Required Fields Check:")
        for field in required_fields:
            status = "✅" if claim_record.get(field) else "❌"
            print(f"   {status} {field}: {claim_record.get(field, 'MISSING')}")

        if missing_fields or not claim_record:
            print(f"❌ VALIDATION FAILED: Missing fields: {missing_fields}")
            parsed = [{
                "timestamp": datetime.utcnow().isoformat(),
                "claim_id": claim_id,
                "identifier": identifier,  # ✅ Include identifier
                "step": "document_verifier_agent",
                "status": "failed",
                "reason": f"Incomplete claim record: missing {', '.join(missing_fields) if missing_fields else 'claim_record'}",
                "confidence_score": 0.0,
            }]
            log_trace(claim_id, "document_verifier_agent_validation_failed", {
                "output": parsed[0],
                "missing_fields": missing_fields,
                "identifier": identifier  # ✅ Include identifier
            })

            print(f"🏁 Document Verifier Agent Failed - Incomplete Record")
            print(f"📋 === DOCUMENT VERIFIER AGENT FINISHED ===\n")
            return {"document_verification_result": parsed, "input": state_data, "identifier": identifier}

        print(f"✅ Claim record validation passed - all required fields present")

        if is_valid_claim:
            print(f"✅ PRE-VALIDATED CLAIM: Bypassing LLM verification")
            print(f"   Reason: {reason or 'Claim validated based on input data=True.'}")
            parsed = [{
                "timestamp": datetime.utcnow().isoformat(),
                "claim_id": claim_id,
                "identifier": identifier,  # ✅ Include identifier
                "step": "document_verifier_agent",
                "status": "passed",
                "reason": reason or "Claim validated based on input data=True.",
                "confidence_score": 0.9,
            }]
            log_trace(claim_id, "document_verifier_agent_prevalidated", {
                "output": parsed[0],
                "identifier": identifier  # ✅ Include identifier
            })

            print(f"🏁 Document Verifier Agent Completed - Pre-validated")
            print(f"📋 === DOCUMENT VERIFIER AGENT FINISHED ===\n")
            return {"document_verification_result": parsed, "input": state_data, "identifier": identifier}

        # Construct prompt for LLM
        print(f"🔄 Proceeding with LLM-based document verification...")
        print(f"📝 Constructing prompt for LLM...")
        prompt = document_verifier_agent_prompt.get_prompt(policy_id, claim_record, rules)

        log_trace(claim_id, "document_verifier_agent_llm_call", {
            "prompt_length": len(prompt),
            "action": "document_verification_analysis",
            "rules_count": len(rules),
            "identifier": identifier  # ✅ Include identifier
        })

        print(f"🤖 Making LLM call for document verification...")
        response = llm.invoke(
            [HumanMessage(content=prompt)],
            config={"run_name": "DocumentVerificationCheck"}
        )
        print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
        print(f"📄 Raw LLM Response:\n{response.content}")

        try:
            response_content = response.content.strip().replace("```json", "").replace("```", "")
            parsed = json.loads(response_content)
            print(f"✅ LLM Response Parsed Successfully")
            if isinstance(parsed, list) and parsed:
                result = parsed[0]
                print(f"   Status: {result.get('status', 'unknown')}")
                print(f"   Confidence Score: {result.get('confidence_score', 'unknown')}")
                print(f"   Reason: {result.get('reason', 'No reason provided')}")

            if not isinstance(parsed, list) or not parsed or not isinstance(parsed[0], dict):
                raise ValueError("Invalid LLM output: Expected a list with a dictionary")

            log_trace(claim_id, "document_verifier_agent_parse_success", {
                "parsed_result": parsed[0],
                "parsing_successful": True,
                "identifier": identifier  # ✅ Include identifier
            })

        except (json.JSONDecodeError, ValueError) as e:
            print(f"❌ Failed to parse LLM response: {e}")
            print(f"📄 Raw response: {response_content}")
            log_trace(claim_id, "document_verifier_agent_error", {
                "error": str(e),
                "raw_response": response.content,
                "prompt": prompt,
                "identifier": identifier  # ✅ Include identifier
            })
            parsed = [{
                "timestamp": datetime.utcnow().isoformat(),
                "claim_id": claim_id,
                "identifier": identifier,  # ✅ Include identifier
                "step": "document_verifier_agent",
                "status": "failed",
                "reason": f"Unable to parse LLM output: {str(e)}",
                "confidence_score": 0.0,
            }]
            print(f"🔄 Using fallback result due to parsing error")

        parsed[0]["raw_llm_response"] = response.content
        final_result = parsed[0]

        print(f"📋 Final Document Verification Result:")
        print(f"   Status: {final_result.get('status')}")
        print(f"   Confidence Score: {final_result.get('confidence_score')}")
        print(f"   Reason: {final_result.get('reason')}")
        print(f"   Timestamp: {final_result.get('timestamp')}")

        log_trace(claim_id, "document_verifier_agent_result", {
            "output": final_result,
            "identifier": identifier  # ✅ Include identifier
        })

        output = {
            "document_verification_result": parsed,
            "input": state_data,
            "identifier": identifier  # ✅ Include identifier
        }

        print(f"🏁 Document Verifier Agent Completed")
        print(f"   Output Keys: {list(output.keys())}")
        print(f"📋 === DOCUMENT VERIFIER AGENT FINISHED ===\n")

        log_trace(claim_id, "document_verifier_agent_complete", {
            "agent_completed": True,
            "final_status": final_result.get('status'),
            "confidence": final_result.get('confidence_score'),
            "output_keys": list(output.keys()),
            "identifier": identifier  # ✅ Include identifier
        })

        return output

    return RunnableLambda(run)
