import json
from typing import Dict

from langchain_core.runnables import Runnable
from src.common_utilities.logger import log_trace


def final_communication_agent() -> Runnable:
    """
    Final communication agent that handles approved claims and generates final communication.
    This agent is called when the claim looks good on all aspects.
    """

    def run_agent(state: Dict) -> Dict:
        print(f"\n📞 === FINAL COMMUNICATION AGENT STARTED ===")
        print(f"📄 Input State Keys: {list(state.keys())}")
        
        # Extract relevant information from state
        claim_id = state.get("policy_id", "unknown")
        decision = state.get("decision", "approved")
        reason = state.get("reason", "Claim approved - all checks passed")
        decision_result = state.get("decision_result", {})
        
        print(f"📊 Final Communication Input Analysis:")
        print(f"   Claim ID: {claim_id}")
        print(f"   Decision: {decision}")
        print(f"   Reason: {reason}")
        print(f"   Decision Result Available: {bool(decision_result)}")
        
        log_trace(
            claim_id=claim_id,
            step="final_communication_agent_start",
            output={
                "agent": "final_communication_agent",
                "input_keys": list(state.keys()),
                "claim_id": claim_id,
                "decision": decision,
                "reason_length": len(reason),
                "decision_result_available": bool(decision_result)
            }
        )

        # Generate final communication message
        print(f"✅ Generating final communication for approved claim...")
        
        communication_message = f"""
Dear Policyholder,

We are pleased to inform you that your insurance claim (ID: {claim_id}) has been approved.

Decision: {decision.upper()}
Reason: {reason}

Your claim has successfully passed all verification checks including:
- Document verification
- Fraud detection screening
- Eligibility verification
- Summary review

The approved claim will be processed for payment according to your policy terms.

If you have any questions, please contact our customer service department.

Thank you for choosing our insurance services.

Best regards,
Claims Processing Team
"""
        
        print(f"📝 Final Communication Generated:")
        print(f"   Message Length: {len(communication_message)} characters")
        print(f"   Status: CLAIM APPROVED - READY FOR PAYMENT")
        
        log_trace(
            claim_id=claim_id,
            step="final_communication_agent_message_generated",
            output={
                "communication_generated": True,
                "message_length": len(communication_message),
                "claim_status": "approved_ready_for_payment",
                "action": "final_approval_communication"
            }
        )

        # Construct final output
        final_communication_result = {
            "timestamp": "2025-06-26T16:50:00",
            "claim_id": claim_id,
            "step": "final_communication_agent",
            "status": "completed",
            "decision": decision,
            "reason": reason,
            "communication_message": communication_message,
            "next_action": "process_payment",
            "workflow_complete": True
        }
        
        print(f"📋 Final Communication Result:")
        print(f"   Status: {final_communication_result['status']}")
        print(f"   Next Action: {final_communication_result['next_action']}")
        print(f"   Workflow Complete: {final_communication_result['workflow_complete']}")
        
        log_trace(
            claim_id=claim_id,
            step="final_communication_agent_result",
            output=final_communication_result
        )
        
        output_state = {
            "final_communication_result": final_communication_result,
            "communication_message": communication_message,
            "workflow_status": "completed_approved",
            "reason": reason,
            "next_action": "process_payment",
            "input": state,
        }
        
        print(f"🏁 Final Communication Agent Completed")
        print(f"   Output Keys: {list(output_state.keys())}")
        print(f"   Workflow Status: {output_state['workflow_status']}")
        print(f"📞 === FINAL COMMUNICATION AGENT FINISHED ===\n")
        
        log_trace(
            claim_id=claim_id,
            step="final_communication_agent_complete",
            output={
                "agent_completed": True,
                "workflow_status": "completed_approved",
                "output_keys": list(output_state.keys()),
                "next_action": "process_payment"
            }
        )

        state.update({
            "final_communication_result": final_communication_result,
            "communication_message": communication_message,
            "workflow_status": "completed_approved",
            "reason": reason,
            "next_action": "process_payment",
            "decision": "completed_approved"
        })

        return state

    return run_agent