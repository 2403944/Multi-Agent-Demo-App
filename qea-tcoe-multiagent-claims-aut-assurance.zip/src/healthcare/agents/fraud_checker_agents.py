from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_core.messages import HumanMessage
import json
import os
from dotenv import load_dotenv
from langsmith import traceable
# Assuming these imports exist in your project setup
from src.common_utilities.logger import log_trace
from src.healthcare.state import GraphState  # Assuming GraphState is defined here
from src.common_layers.llm_layer.llm_manager import LLMManager
from langsmith.run_helpers import trace
load_dotenv()
# @traceable(name="duplicate_checker", run_type="llm")
def fraud_duplicate_claim_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:

        llm = LLMManager().get_llm()
        print(type(llm))

        print(f"\n🔍 === FRAUD DUPLICATE CLAIM CHECKER STARTED ===")
        print(state)

        state_data = state
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        policy_id = claim_record.get("policy_id", "UNKNOWN")

        print(f"🆔 Claim ID: {claim_id}")
        print(f"📄 Claim Record Fields: {len(claim_record)}")
        print(f"📝 Notes Count: {len(notes)}")

        log_trace(
            claim_id=policy_id,
            step="fraud_duplicate_claim_checker_start",
            output={
                "agent": "fraud_duplicate_claim_checker",
                "claim_id": claim_id,
                "notes_count": len(notes),
                "claim_record_fields": len(claim_record)
            }
        )

        # === STEP 1: Load Past Claims ===
        try:
            import json
            with open("past_data_claims/past_claims.json", "r") as f:
                past_claims_data = json.load(f)
            claim_count = len(past_claims_data)
            print(f"Total number of past claims: {claim_count}")

            # Optional: Filter by same policy or patient, depending on your logic
            relevant_past_claims = [
                claim for claim in past_claims_data
                if claim.get("policy_id") == policy_id
            ]
        except Exception as e:
            print(f"⚠️ Could not load past claims: {e}")
            relevant_past_claims = []

        print(f"📚 Found {len(relevant_past_claims)} relevant past claims")
        print("==========================================================")
        print(f"Matching past claim : \n{relevant_past_claims}")
        print("==========================================================")

        # === STEP 2: Check for pre-existing note ===
        matching_note = next(
            (n for n in notes if "fraud_checker_agent - duplicate_claim_review" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No duplicate claim detected."

        print(f"🔍 Checking for existing duplicate review notes...")
        print(f"📝 Matching Note Found: {bool(matching_note)}")

        if matching_note:
            reason = matching_note
            print(f"✅ Using existing note for duplicate check")
            print(f"📝 Note: {reason}")

            log_trace(
                claim_id=policy_id,
                step="fraud_duplicate_claim_checker_note_found",
                output={"matching_note": matching_note, "using_existing_note": True}
            )
        else:
            print(f"🤖 No existing note found, proceeding with LLM analysis...")

            # === STEP 3: Construct Prompt ===
            prompt = f"""
                You are an AI assistant tasked with validating an insurance claim for fraud detection, specifically for Health Insurance.
                
                Rule: 'duplicate_claim_review'
                
                Your task is to:
                - Determine whether identical or overlapping claims for the same service, or from the same time period for the same patient, have been previously submitted.
                - Analyze the provided 'Claim Record' and compare it with historical claims.
                
                Claim Record (New):
                {json.dumps(claim_record, indent=2)}
                
                Relevant Past Claims:
                {json.dumps(relevant_past_claims, indent=2)}
                
                Based on this information, assess the likelihood of a duplicate claim and assign a fraud score from 0 to 100.
                - If definitely not a duplicate: Score 0.
                - If suspicious but not confirmed (e.g., similar details but different dates/amounts, or overlapping but not identical services): Score between 30 and 70.
                - If highly likely a duplicate: Score above 70.
                
                Respond strictly in the following JSON format:
                {{
                  "status": "not_duplicate" or "suspicious" or "duplicate",
                  "reason": "<brief explanation for the status>",
                  "fraud_score": <integer score between 0 and 100>
                }}
                
                If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
                Do not ask for more data.
                """

            print(f"🔄 Making LLM call for duplicate claim analysis...")

            log_trace(
                claim_id=policy_id,
                step="fraud_duplicate_claim_checker_llm_call",
                output={
                    "prompt_length": len(prompt),
                    "action": "duplicate_claim_analysis",
                    "past_claims_count": len(relevant_past_claims)
                }
            )

            try:

                identifier = state_data.get("identifier", "unknown")
                response = llm.invoke(
                    [HumanMessage(content=prompt)],
                    config={"run_name": "FraudDuplicateClaimCheck", "tags": [identifier]}  # ✅ Optional tags}
                )
                print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
                print(f"📄 Raw Response:\n{response.content}")

                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Unclear duplicate claim status.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                print(f"✅ LLM Response Parsed Successfully")
                print(f"📊 Duplicate Check Result:")
                print(f"   Status: {status_llm}")
                print(f"   Fraud Score: {fraud_score}")
                print(f"   Reason: {reason}")

                if status_llm == "not_duplicate":
                    fraud_score = 0.0
                    print(f"✅ No duplicate detected - Score reset to 0")
                elif fraud_score > 70:
                    status = "failed"
                    print(f"❌ High fraud score - Status: FAILED")
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                    print(f"⚠️ Medium fraud score - Requires manual review")
                else:
                    status = "passed_with_minor_flags"
                    print(f"✅ Low fraud score - Passed with minor flags")

                log_trace(
                    claim_id=policy_id,
                    step="fraud_duplicate_claim_checker_llm_success",
                    output={
                        "status_llm": status_llm,
                        "fraud_score": fraud_score,
                        "final_status": status,
                        "human_review": human_review,
                        "parsing_successful": True
                    }
                )

            except Exception as e:
                print(f"❌ LLM call failed: {e}")
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

                log_trace(
                    claim_id=policy_id,
                    step="fraud_duplicate_claim_checker_llm_error",
                    output={
                        "error": str(e),
                        "fallback_fraud_score": fraud_score,
                        "parsing_successful": False
                    }
                )

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: duplicate_claim_review)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        print(f"📋 Final Duplicate Claim Check Result:")
        print(f"   Status: {status}")
        print(f"   Fraud Score: {fraud_score}")
        print(f"   Human Review Required: {human_review}")
        print(f"   Reason: {reason}")

        log_trace(
            claim_id=policy_id,
            step="fraud_checker_agent.duplicate_claim_review",
            output=output,
        )

        result = {
            "duplicate_claim_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        print(f"🏁 Fraud Duplicate Claim Checker Completed")
        print(f"🔍 === FRAUD DUPLICATE CLAIM CHECKER FINISHED ===\n")

        log_trace(
            claim_id=policy_id,
            step="fraud_duplicate_claim_checker_complete",
            output={
                "agent_completed": True,
                "final_fraud_score": fraud_score,
                "human_review_required": human_review,
                "final_status": status
            }
        )

        return result

    return RunnableLambda(run)


# @traceable(name="inconsistency_checker", run_type="llm")
def fraud_inconsistency_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        print(f"\n🔍 === FRAUD INCONSISTENCY CHECKER STARTED ===")

        llm = LLMManager().get_llm()
        print(type(llm))

        state_data = state
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})

        # 🔽 Commented out: Document text from state
        # document_text = state_data.get("document_text", "")

        # ✅ Load document text from external file
        try:
            with open("past_data_claims/ref_doc_claim_input_1.txt", "r", encoding="utf-8") as file:
                document_text = file.read()
            print("The reference document file was loaded successfully.")
            print("======================================================")
            preview = document_text[:300].strip()
            print(f"📑 First few lines of document:\n{preview}\n... [truncated]\n")
            print("======================================================")
        except FileNotFoundError:
            print("❌ ERROR: ref_doc_claim_input_1.txt not found.")
            document_text = "[ERROR: Document not found.]"
        except Exception as e:
            print(f"❌ ERROR reading document file: {e}")
            document_text = f"[ERROR reading document: {e}]"

        print(f"🆔 Claim ID: {claim_id}")
        print(f"📄 Claim Record Fields: {len(claim_record)}")
        print(f"📝 Notes Count: {len(notes)}")
        print(f"📄 Document Text Length: {len(document_text)} chars")

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_inconsistency_checker_start",
            output={
                "agent": "fraud_inconsistency_checker",
                "claim_id": claim_id,
                "notes_count": len(notes),
                "document_text_length": len(document_text),
                "claim_record_fields": len(claim_record)
            }
        )

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - inconsistency_detection" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No inconsistencies detected."

        print(f"🔍 Checking for existing inconsistency detection notes...")
        print(f"📝 Matching Note Found: {bool(matching_note)}")

        if matching_note:
            reason = matching_note
            print(f"✅ Using existing note for inconsistency check")
            print(f"📝 Note: {reason}")

            log_trace(
                claim_id=state_data.get("policy_id", "UNKNOWN"),
                step="fraud_inconsistency_checker_note_found",
                output={"matching_note": matching_note, "using_existing_note": True}
            )
        else:
            print(f"🤖 No existing note found, proceeding with LLM analysis...")
            prompt = f"""
You are an AI assistant validating a health insurance claim under the 'inconsistency_detection' rule.

Task: Check for inconsistencies between submitted documents and claim details (e.g., mismatched dates of service, different amounts billed vs. approved, conflicting diagnoses, or discrepancies with medical history).

Claim Record:
{json.dumps(claim_record, indent=2)}
Relevant Document Text:
{document_text}

Based on this information, assess the presence of inconsistencies and assign a fraud score from 0 to 100.
- If no inconsistencies found: Score 0.
- If minor inconsistencies (e.g., slight date variations, small amount discrepancies): Score between 30 and 70.
- If major inconsistencies (e.g., conflicting diagnoses, services claimed not matching medical records, significant billing discrepancies): Score above 70.
- if {document_text} is empty, say the document is empty and make score as NAN.
Respond strictly in the following JSON format:
{{
  "status": "consistent" or "inconsistent" or "minor_inconsistencies",
  "reason": "<brief explanation for the consistency/inconsistency>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume minor inconsistencies and assign a score between 30-40.
Do not ask for more data.
"""
            print(f"🔄 Making LLM call for inconsistency analysis...")

            log_trace(
                claim_id=state_data.get("policy_id", "UNKNOWN"),
                step="fraud_inconsistency_checker_llm_call",
                output={
                    "prompt_length": len(prompt),
                    "action": "inconsistency_analysis"
                }
            )

            try:
                identifier = state_data.get("identifier", "unknown")
                response = llm.invoke(
                    [HumanMessage(content=prompt)],
                    config={"run_name": "FraudInconsistencyCheck", "tags": [identifier]}  # ✅ Optional tags}
                )
                print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
                print(f"📄 Raw Response:\n{response.content}")

                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "minor_inconsistencies")
                reason = parsed.get("reason", "Could not verify consistency.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                print(f"✅ LLM Response Parsed Successfully")
                print(f"📊 Inconsistency Check Result:")
                print(f"   Status: {status_llm}")
                print(f"   Fraud Score: {fraud_score}")
                print(f"   Reason: {reason}")

                if status_llm == "consistent":
                    fraud_score = 0.0
                    print(f"✅ Consistent data - Score reset to 0")
                elif fraud_score > 70:
                    status = "failed"
                    print(f"❌ High inconsistency score - Status: FAILED")
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                    print(f"⚠️ Medium inconsistency score - Requires manual review")
                else:
                    status = "passed_with_minor_flags"
                    human_review = False
                    print(f"✅ Low inconsistency score - Passed with minor flags")

                log_trace(
                    claim_id=state_data.get("policy_id", "UNKNOWN"),
                    step="fraud_inconsistency_checker_llm_success",
                    output={
                        "status_llm": status_llm,
                        "fraud_score": fraud_score,
                        "final_status": status,
                        "human_review": human_review,
                        "parsing_successful": True
                    }
                )

            except Exception as e:
                print(f"❌ LLM call failed: {e}")
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

                log_trace(
                    claim_id=state_data.get("policy_id", "UNKNOWN"),
                    step="fraud_inconsistency_checker_llm_error",
                    output={
                        "error": str(e),
                        "fallback_fraud_score": fraud_score,
                        "parsing_successful": False
                    }
                )

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: inconsistency_detection)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        print(f"📋 Final Inconsistency Check Result:")
        print(f"   Status: {status}")
        print(f"   Fraud Score: {fraud_score}")
        print(f"   Human Review Required: {human_review}")
        print(f"   Reason: {reason}")

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.inconsistency_detection",
            output=output,
        )

        result = {
            "inconsistency_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        print(f"🏁 Fraud Inconsistency Checker Completed")
        print(f"🔍 === FRAUD INCONSISTENCY CHECKER FINISHED ===\n")

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_inconsistency_checker_complete",
            output={
                "agent_completed": True,
                "final_fraud_score": fraud_score,
                "human_review_required": human_review,
                "final_status": status
            }
        )

        return result

    return RunnableLambda(run)


def fraud_provider_verification_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        print(f"\n🔍 === FRAUD PROVIDER VERIFICATION CHECKER STARTED ===")

        llm = LLMManager().get_llm()
        print(f"Using LLM: {type(llm)}")

        state_data = state
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        provider_details = claim_record.get("provider_details", None)

        # Load document text
        try:
            with open("past_data_claims/ref_doc_claim_input_1.txt", "r", encoding="utf-8") as file:
                document_text = file.read()
            # print("The reference document file was loaded successfully.")
            # print("======================================================")
            # preview = document_text[:300].strip()
            # print(f"📑 First few lines of document:\n{preview}\n... [truncated]\n")
            # print("======================================================")
        except FileNotFoundError:
            print("❌ ERROR: ref_doc_claim_input_1.txt not found.")
            document_text = ""
        except Exception as e:
            print(f"❌ ERROR reading document file: {e}")
            document_text = ""

        # Load valid providers list JSON
        try:
            with open("past_data_claims/valid_providers.json", "r", encoding="utf-8") as vp_file:
                valid_providers = json.load(vp_file)
            print("Valid providers file loaded successfully.")
        except Exception as e:
            print(f"❌ ERROR loading valid providers file: {e}")
            valid_providers = []

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - provider_verification" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "Provider verified."

        if matching_note:
            reason = matching_note
        else:
            print(f"🤖 No existing note found, proceeding with LLM analysis...")

            prompt = f"""
You are an AI assistant validating a health insurance claim under the 'provider_verification' rule.

Your task is to:
- Determine if the listed healthcare provider (hospital, doctor, clinic, etc.) exists and is legitimate.
- Look for any signs that the provider information might be fabricated or suspicious.
- Utilize the 'Claim Record', 'Document Text', and the list of valid known providers below to verify provider details.

If provider details are missing or empty in the claim record and document text, you must assign a fraud score of 100 and status "failed" with reason "Provider details missing."

Claim Record:
{json.dumps(claim_record, indent=2)}
Provider Details (from claim record): {json.dumps(provider_details, indent=2) if provider_details else "None"}
Valid Providers List:
{json.dumps(valid_providers, indent=2)}
Relevant Document Text:
{document_text}

Based on this information, assess the legitimacy of the provider and assign a fraud score from 0 to 100.
- If provider is clearly legitimate/verified: Score 0.
- If suspicious but not confirmed (e.g., vague provider info, hard to cross-reference, new/unfamiliar provider): Score between 30 and 70.
- If the provider seems highly fabricated or linked to known fraud: Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "verified" or "suspicious" or "fabricated" or "failed",
  "reason": "<brief explanation>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
Do not ask for more data.
"""

            try:
                identifier = state_data.get("identifier", "unknown")
                response = llm.invoke(
                    [HumanMessage(content=prompt)],
                    config={"run_name": "FraudProviderCheck", "tags": [identifier]}  # ✅ Optional tags}
                )
                print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
                print(f"📄 Raw Response:\n{response.content}")

                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Provider identity unclear.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "verified":
                    fraud_score = 0.0
                    status = "passed"
                    human_review = False
                elif status_llm == "failed":
                    status = "failed"
                    human_review = False
                    fraud_score = 100.0
                elif fraud_score > 70:
                    status = "failed"
                    human_review = False
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: provider_verification)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        print(f"📋 Final Provider Verification Result:")
        print(f"   Status: {status}")
        print(f"   Fraud Score: {fraud_score}")
        print(f"   Human Review Required: {human_review}")
        print(f"   Reason: {reason}")

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.provider_verification",
            output=output,
        )

        print(f"🏁 Fraud Provider Verification Checker Completed")
        print(f"🔍 === FRAUD PROVIDER VERIFICATION CHECKER FINISHED ===\n")

        return {
            "provider_verification_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)

# @traceable(name="reasonability_checker", run_type="llm")
def fraud_service_reasonability_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        print(f"\n🔍 === FRAUD SERVICE REASONABILITY CHECKER STARTED ===")

        llm = LLMManager().get_llm()
        print(type(llm))

        state_data = state
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        medical_condition = claim_record.get("medical_condition", None)
        services_claimed = claim_record.get("services_claimed", None)

        # Load document text from external file for context
        try:
            with open("past_data_claims/ref_doc_claim_input_1.txt", "r", encoding="utf-8") as file:
                document_text = file.read()
            print("The reference document file was loaded successfully.")
            # print("======================================================")
            # preview = document_text[:300].strip()
            # print(f"📑 First few lines of document:\n{preview}\n... [truncated]\n")
            # print("======================================================")
        except FileNotFoundError:
            print("❌ ERROR: ref_doc_claim_input_2.txt not found.")
            document_text = "[ERROR: Document not found.]"
        except Exception as e:
            print(f"❌ ERROR reading document file: {e}")
            document_text = f"[ERROR reading document: {e}]"

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - service_reasonability_check" in n),
            None,
        )

        if matching_note:
            reason = matching_note
        else:
            print(f"🤖 No existing note found, proceeding with LLM analysis...")

            prompt = f"""
You are an AI assistant reviewing a health insurance claim for the 'service_reasonability_check' rule.

Task: Evaluate if the claimed services are medically reasonable and necessary given the policyholder’s reported condition, medical history (if available), and other supporting documents. Look for over-utilization, unbundled services, or services unrelated to the diagnosis.

Claim Record:
{json.dumps(claim_record, indent=2)}
Policyholder's Medical Condition: {medical_condition}
Services Claimed: {services_claimed}
Relevant Document Text:
{document_text}
Note : If medical_condition, services_claimed are None, check for the same information from the Document Text:{document_text}

Based on this information, assess the medical reasonability of the services and assign a fraud score from 0 to 100.
- If services are clearly medically reasonable and necessary: Score 0.
- If services are somewhat suspicious (e.g., higher frequency than typical, slightly unusual combination of services for condition): Score between 30 and 70.
- If services appear highly unreasonable, unnecessary, or abusive (e.g., excessive billing, services not justified by diagnosis): Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "reasonable" or "suspicious" or "unreasonable",
  "reason": "<brief explanation>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
Do not ask for more data.
"""
            try:
                identifier = state_data.get("identifier", "unknown")
                response = llm.invoke(
                    [HumanMessage(content=prompt)],
                    config={"run_name": "FraudServiceReasonabilityCheck","tags": [identifier] }# ✅ Optional tags}
                )




                print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
                print(f"📄 Raw Response:\n{response.content}")

                response_content = response.content.strip().replace("```json", "").replace("```", "")
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Service reasonability unclear.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if fraud_score > 70:
                    status = "failed"
                    human_review = True
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: service_reasonability_check)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }
        print(f"📋 Final Service Reasonability Result:")
        print(f"   Status: {status}")
        print(f"   Fraud Score: {fraud_score}")
        print(f"   Human Review Required: {human_review}")
        print(f"   Reason: {reason}")

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.service_reasonability_check",
            output=output,
        )
        print(f"🏁 Fraud Service Reasonability Checker Completed")
        print(f"🔍 === FRAUD SERVICE REASONABILITY CHECKER FINISHED ===\n")

        return {
            "service_reasonability_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


# Helper function to get all health fraud checker agents
# def get_health_fraud_checker_agents(llm):
#     return {
#         "duplicate_claim": fraud_duplicate_claim_checker(llm),
#         "inconsistency_detection": fraud_inconsistency_checker(llm),
#         "provider_verification": fraud_provider_verification_checker(llm),
#         "service_reasonability": fraud_service_reasonability_checker(llm),
#     }

def get_health_fraud_checker_agents(llm):
    agents = {
        "duplicate_claim": fraud_duplicate_claim_checker(llm),
        "inconsistency_detection": fraud_inconsistency_checker(llm),
        "provider_verification": fraud_provider_verification_checker(llm),
        "service_reasonability": fraud_service_reasonability_checker(llm),
    }

    def fraud_checker_fn(state):
        results = {}
        for key, agent in agents.items():
            results[key] = agent.invoke(state)
        print("===============================================")
        print(f"Fraud Detector Combined results : \n {results}")
        print("===============================================")

        # Store the results into the state under a new key
        updated_state = {
            **state,  # existing keys
            "fraud_detection_results": results  # new key
        }

        return updated_state

    return RunnableLambda(fraud_checker_fn).with_config({"run_name": "FraudDetectionAgent"})


