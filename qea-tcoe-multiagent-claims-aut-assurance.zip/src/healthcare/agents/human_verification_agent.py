import json
from typing import Dict

from langchain_core.runnables import Runnable
from src.common_utilities.logger import log_trace


def human_verification_agent() -> Runnable:
    """
    Human verification agent that handles claims requiring manual review.
    This agent is called when something doesn't look right with the claim.
    """

    def run_agent(state: Dict) -> Dict:
        print(f"\n👨‍💼 === HUMAN VERIFICATION AGENT STARTED ===")
        print(f"📄 Input State Keys: {list(state.keys())}")
        
        # Extract relevant information from state
        claim_id = state.get("policy_id", "unknown")
        decision = state.get("decision", "requires_review")
        reason = state.get("reason", "Claim requires human verification")
        decision_result = state.get("decision_result", {})
        document_result = state.get("document_check_result", "")
        
        print(f"📊 Human Verification Input Analysis:")
        print(f"   Claim ID: {claim_id}")
        print(f"   Decision: {decision}")
        print(f"   Reason: {reason}")
        print(f"   Decision Result Available: {bool(decision_result)}")
        print(f"   Document Result Available: {bool(document_result)}")
        
        log_trace(
            claim_id=claim_id,
            step="human_verification_agent_start",
            output={
                "agent": "human_verification_agent",
                "input_keys": list(state.keys()),
                "claim_id": claim_id,
                "decision": decision,
                "reason_length": len(reason),
                "decision_result_available": bool(decision_result),
                "document_result_available": bool(document_result)
            }
        )

        # Generate human verification request
        print(f"⚠️ Flagging claim for human verification...")
        
        verification_request = f"""
HUMAN VERIFICATION REQUIRED

Claim ID: {claim_id}
Current Status: {decision.upper()}
Review Reason: {reason}

CLAIM DETAILS REQUIRING MANUAL REVIEW:
- Document verification issues detected
- Potential fraud indicators found
- Complex claim circumstances
- Policy compliance questions

RECOMMENDED ACTIONS FOR HUMAN REVIEWER:
1. Review all submitted documentation thoroughly
2. Verify provider credentials and service authenticity
3. Cross-check claim details against policy terms
4. Investigate any fraud indicators
5. Contact claimant if additional information needed
6. Make final determination based on manual review

PRIORITY: HIGH - Manual review required before claim processing

Please assign to qualified claims adjuster for detailed investigation.
"""
        
        print(f"📝 Human Verification Request Generated:")
        print(f"   Request Length: {len(verification_request)} characters")
        print("================================================================")
        print(f"Verification Request send to Human Review : \n {verification_request}")
        print("================================================================")

        print(f"   Status: CLAIM FLAGGED - REQUIRES HUMAN REVIEW")
        print(f"   Priority: HIGH")
        
        log_trace(
            claim_id=claim_id,
            step="human_verification_agent_request_generated",
            output={
                "verification_request_generated": True,
                "request_length": len(verification_request),
                "claim_status": "flagged_for_human_review",
                "priority": "high",
                "action": "manual_review_required"
            }
        )

        # Construct human verification result
        human_verification_result = {
            "timestamp": "2025-06-26T16:50:00",
            "claim_id": claim_id,
            "step": "human_verification_agent",
            "status": "pending_human_review",
            "decision": "requires_manual_review",
            "reason": reason,
            "verification_request": verification_request,
            "priority": "high",
            "next_action": "assign_to_human_reviewer",
            "workflow_complete": False,
            "escalation_required": True
        }
        
        print(f"📋 Human Verification Result:")
        print(f"   Status: {human_verification_result['status']}")
        print(f"   Priority: {human_verification_result['priority']}")
        print(f"   Next Action: {human_verification_result['next_action']}")
        print(f"   Escalation Required: {human_verification_result['escalation_required']}")
        
        log_trace(
            claim_id=claim_id,
            step="human_verification_agent_result",
            output=human_verification_result
        )
        
        output_state = {
            "human_verification_result": human_verification_result,
            "verification_request": verification_request,
            "workflow_status": "pending_human_review",
            "reason": reason,
            "escalation_required": True,
            "next_action": "assign_to_human_reviewer",
            "priority": "high",
            "input": state,
        }
        
        print(f"🏁 Human Verification Agent Completed")
        print(f"   Output Keys: {list(output_state.keys())}")
        print(f"   Workflow Status: {output_state['workflow_status']}")
        print(f"   Escalation Required: {output_state['escalation_required']}")
        print(f"👨‍💼 === HUMAN VERIFICATION AGENT FINISHED ===\n")


        log_trace(
            claim_id=claim_id,
            step="human_verification_agent_complete",
            output={
                "agent_completed": True,
                "workflow_status": "pending_human_review",
                "output_keys": list(output_state.keys()),
                "escalation_required": True,
                "priority": "high"
            }
        )

        # Update the existing state with the new values
        state.update({
            "human_verification_result": human_verification_result,
            "verification_request": verification_request,
            "workflow_status": "pending_human_review",
            "reason": reason,
            "escalation_required": True,
            "next_action": "assign_to_human_reviewer",
            "priority": "high",
            "decision": "pending_human_review",
        })

        return state

    return run_agent