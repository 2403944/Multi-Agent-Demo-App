from langchain_core.runnables import Runnable, RunnableLambda
from langchain_openai import AzureChatOpenAI
import os, json, re
from src.healthcare.agents.supervisors.supervisor_agent import *
from src.common_utilities.logger import log_trace
from src.common_layers.llm_layer.llm_manager import LLMManager
from src.healthcare.state import GraphState
from typing import Dict, Any
from langsmith import traceable, trace
from dotenv import load_dotenv

load_dotenv()


def get_summarizer_agent(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        with trace(name="SummarizerRun", run_type="llm") as t:
            print(f"\n📝 === SUMMARIZER AGENT STARTED ===")

            claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
            identifier = state.get("identifier", "unknown")  # ✅ Extract identifier
            notes = state.get("claim_record", {}).get("notes", [])
            claim_record = state.get("claim_record", {})
            document_check_result = state.get("document_check_result", {})
            fraud_detection_results = state.get("fraud_detection_results", {})

            # Attach inputs to trace
            t.add_inputs({
                "identifier": identifier,  # ✅ Include identifier
                "claim_id": claim_id,
                "notes_count": len(notes),
                "claim_record": claim_record,
                "document_check_result": document_check_result,
                "fraud_detection_results": fraud_detection_results
            })

            # Build prompt
            prompt = f"""
            You are an AI assistant summarizing a vehicle insurance claim.

            Identifier: {identifier}

            Here are the claim details:

            - Claim ID: {claim_id}
            - Claim Record Details: {json.dumps(claim_record, indent=2)}
            - Notes: {notes}
            - Document Check Results: {json.dumps(document_check_result, indent=2)}
            - Fraud Detection Results: {json.dumps(fraud_detection_results, indent=2)}

            Based on all this information, generate:
            - A short summary suitable for internal review.
            - A summary_accuracy_score (between 0 and 1).

            Respond ONLY in this JSON format:
            {{
                "summary": "<summary text>",
                "summary_accuracy_score": <float>
            }}
            """

            log_trace(claim_id, "summarizer_agent_llm_call", {
                "prompt_length": len(prompt),
                "identifier": identifier  # ✅ Include identifier
            })

            # Call LLM
            response = llm.chat.completions.create(
                model=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
                messages=[{"role": "user", "content": prompt}]
            ).choices[0].message

            response_content = response.content.strip()
            print(f"📄 Raw LLM Response:\n{response_content}")

            # --- Robust JSON parsing ---
            parsed = None
            try:
                parsed = json.loads(response_content)
            except json.JSONDecodeError:
                match = re.search(r"\{.*\}", response_content, re.DOTALL)
                if match:
                    try:
                        parsed = json.loads(match.group(0))
                    except Exception as e:
                        print(f"❌ Still failed to parse JSON block: {e}")

            if not parsed or not isinstance(parsed, dict):
                print("⚠️ Falling back due to invalid LLM response")
                parsed = {
                    "summary": f"Claim {claim_id}: {notes[:100]}... (truncated).",
                    "summary_accuracy_score": 0.5,
                }

            output = {
                "identifier": identifier,  # ✅ Include identifier
                "summary": parsed.get("summary", "No summary generated"),
                "summary_accuracy_score": float(parsed.get("summary_accuracy_score", 0.0)),
            }

            # Attach outputs to trace
            t.add_outputs(output)

            # Log structured result
            log_trace(claim_id, "summarizer_agent_result", output)

            print(f"📋 Final Summary Output:")
            print(f"   Summary: {output['summary']}")
            print(f"   Accuracy Score: {output['summary_accuracy_score']}")

            state["summary"] = output
            return output

    return RunnableLambda(run)
