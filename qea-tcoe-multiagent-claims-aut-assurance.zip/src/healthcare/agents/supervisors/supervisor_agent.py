from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_community.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

from src.common_layers.llm_layer.llm_manager import LLMManager
from src.common_utilities.logger import log_trace

llm = LLMManager().get_llm()

from langchain.schema import HumanMessage


class ClaimClassifierAgent:
    def __init__(self, llm):
        self.llm = llm

    def classify(self, input: dict) -> str:
        print(f"\n🏷️ === CLAIM CLASSIFIER AGENT STARTED ===")
        
        claim_type = input.get("claim_type")
        claim_details = input.get("claim_details", "")
        policy_id = input.get("policy_id", "unknown")
        
        print(f"📋 Classification Input:")
        print(f"   Policy ID: {policy_id}")
        print(f"   Claim Type: {claim_type}")
        print(f"   Claim Details: {claim_details}")
        print(f"   Input Keys: {list(input.keys())}")
        
        log_trace(
            claim_id=policy_id,
            step="claim_classifier_agent_start",
            output={
                "agent": "claim_classifier_agent",
                "policy_id": policy_id,
                "claim_type": claim_type,
                "claim_details_length": len(claim_details),
                "input_keys": list(input.keys())
            }
        )
        
        prompt = f"""
You are a classification agent.
Given the following insurance claim details, identify the appropriate claim category.

Claim Details:
Type: {claim_type}
Description: {claim_details}

Respond with one of: 'Auto_Insurance', 'health', or 'base'
"""

        print(f"🔄 Making LLM call for claim classification...")
        print(f"📝 Prompt length: {len(prompt)} chars")
        
        log_trace(
            claim_id=policy_id,
            step="claim_classifier_agent_llm_call",
            output={
                "prompt_length": len(prompt),
                "action": "claim_classification"
            }
        )

        response = self.llm.invoke([HumanMessage(content=prompt)])
        classification = response.content.strip().lower()
        
        print(f"✅ LLM Response Received: '{response.content.strip()}'")
        print(f"🔄 Processing classification: '{classification}'")

        # Optional validation fallback
        original_classification = classification
        if classification not in ["auto_insurance", "health", "base"]:
            print(f"⚠️ Invalid classification '{classification}', defaulting to 'base'")
            classification = "base"
        else:
            print(f"✅ Valid classification: '{classification}'")
        
        # Convert back to proper case for return
        if classification == "auto_insurance":
            final_classification = "Auto_Insurance"
        else:
            final_classification = classification
            
        print(f"📊 Classification Result:")
        print(f"   Original LLM Response: '{original_classification}'")
        print(f"   Processed Classification: '{classification}'")
        print(f"   Final Classification: '{final_classification}'")
        
        log_trace(
            claim_id=policy_id,
            step="claim_classifier_agent_result",
            output={
                "original_llm_response": response.content.strip(),
                "processed_classification": classification,
                "final_classification": final_classification,
                "classification_valid": original_classification in ["auto_insurance", "health", "base"]
            }
        )
        
        print(f"🏁 Claim Classifier Agent Completed")
        print(f"🏷️ === CLAIM CLASSIFIER AGENT FINISHED ===\n")
        
        log_trace(
            claim_id=policy_id,
            step="claim_classifier_agent_complete",
            output={
                "agent_completed": True,
                "final_classification": final_classification
            }
        )

        return final_classification
