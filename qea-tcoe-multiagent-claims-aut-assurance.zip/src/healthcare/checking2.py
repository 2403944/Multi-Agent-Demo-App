import os
from langsmith import Client, traceable
import os
from dotenv import load_dotenv

# Load variables from keys.env into the environment
load_dotenv("keys.env")
# 1. Check environment variables
print("🔑 LANGCHAIN_API_KEY:", os.getenv("LANGCHAIN_API_KEY"))
print("📂 LANGCHAIN_PROJECT:", os.getenv("LANGCHAIN_PROJECT"))
print("🌐 LANGCHAIN_ENDPOINT:", os.getenv("LANGCHAIN_ENDPOINT"))

# 2. Try creating a client
try:
    client = Client()
    print("✅ Successfully created LangSmith client")
    print("   Current project:", client.project)
except Exception as e:
    print("❌ Could not create LangSmith client:", e)

# 3. Send a trivial traceable run
@traceable(name="ConnectivityTest", run_type="chain")
def random(x: int, y: int) -> int:
    return x + y

if __name__ == "__main__":
    result = random(2, 3)
    print("Result of test_run:", result)
    print("➡️ Check your LangSmith dashboard for a run named 'ConnectivityTest'")
