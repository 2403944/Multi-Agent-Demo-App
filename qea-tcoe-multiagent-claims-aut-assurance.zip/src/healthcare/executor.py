import json
from pathlib import Path
from datetime import datetime
from langsmith import traceable, trace, Client
from dotenv import load_dotenv

# Load environment variables from keys.env
load_dotenv("keys.env")

from src.common_layers.llm_layer.llm_manager import LLMManager
from src.healthcare.workflows.healthcare_workflow import create_health_graph
from src.common_utilities.logger import log_trace

client = Client()

print("🚀 === HEALTHCARE CLAIMS PROCESSING SYSTEM STARTED ===")
print(f"⏰ Start Time: {datetime.now().isoformat()}")
print("🔧 Project initiated successfully")


@traceable(name="HealthcareExecutor", run_type="chain")
def run_healthcare_executor(claim_input: dict):
    # Phase 0: input analysis
    with trace(name="InputAnalysis", run_type="tool") as t0:
        t0.add_inputs({"claim_input": claim_input})

        input_summary = {
            "identifier": claim_input.get("identifier"),
            "policy_id": claim_input['policy_id'],
            "domain": claim_input['domain'],
            "claim_amount": claim_input['claim_record']['claim_amount'],
            "notes_count": len(claim_input['claim_record']['notes']),
            "policy_start": claim_input['claim_record']['policy_start'],
            "policy_end": claim_input['claim_record']['policy_end'],
            "accident_date": claim_input['claim_record']['accident_date'],
        }
        log_trace(
            claim_id=claim_input['policy_id'],
            step="healthcare_executor_start",
            output={"executor": "healthcare_executor", **input_summary}
        )
        t0.add_outputs(input_summary)

    input_data = claim_input

    print(f"\n🔄 === CREATING HEALTHCARE WORKFLOW ===")
    print(f"🏗️ Building healthcare workflow graph...")

    # Phase 1: workflow creation
    with trace(name="WorkflowCreation", run_type="chain") as t1:
        t1.add_inputs({"identifier":input_data.get("identifier"),"input_data_keys": list(input_data.keys())})
        log_trace(
            claim_id=claim_input['policy_id'],
            step="healthcare_executor_workflow_creation",
            output={
                "action": "creating_health_graph",
                "input_data_keys": list(input_data.keys())
            }
        )
        workflow = create_health_graph(claim_input)
        # Expose graph metadata for evaluation
        t1.add_outputs({
            "identifier":claim_input.get("identifier"),
            "workflow_created": True,
            "nodes": ["DocumentVerifier", "FraudDetector", "Summarizer", "DecisionSupervisor"],
            "edges": [
                "DocumentVerifier -> FraudDetector/Summarizer",
                "FraudDetector -> Summarizer",
                "Summarizer -> DecisionSupervisor",
                "DecisionSupervisor -> END"
            ]
        })
        print(f"✅ Healthcare workflow graph created successfully")

    # Phase 2: Workflow Invoke
    with trace(name="WorkflowInvoke", run_type="chain") as t2:
        t2.add_inputs({"workflow": str(workflow), "policy_id": claim_input['policy_id'],"identifier":claim_input.get("identifier")})
        log_trace(
            claim_id=claim_input['policy_id'],
            step="healthcare_executor_workflow_invoke",
            output={
                "action": "invoking_workflow",
                "policy_id": claim_input['policy_id'],
                "workflow_created": True
            }
        )

        # Run the workflow once and get the full assembled result
        result = workflow.invoke(input_data)
        actual_path = result.get("__path__", [])

        # Log outputs for trace visibility
        t2.add_outputs({
            "result_keys": list(result.keys()),
            "actual_path": actual_path
        })

        print(f"✅ Workflow execution completed")

    # Phase 3: result processing
    with trace(name="ResultProcessing", run_type="tool") as t3:
        t3.add_inputs({"workflow_result": result,"identifier":claim_input.get("identifier")})
        log_trace(
            claim_id=claim_input['policy_id'],
            step="healthcare_executor_workflow_result",
            output={
                "action": "workflow_completed",
                "result_keys": list(result.keys()),
                "workflow_successful": True
            }
        )

        decision = result.get("decision", "N/A")
        reason = result.get("reason", "Document Verification Flow Incomplete")
        summary = result.get("summary", "Summary not available.")
        policy_id = result.get("policy_id", "unknown")

        # Attach evaluation‑ready metadata
        t3.add_outputs({
            "final_decision": decision,
            "policy_id": policy_id,
            "summary": summary,
            "reason": reason,
            "summary_length": len(summary),
            "reason_length": len(reason)
        })

        # Basic completeness checks
        client.create_feedback(
            run_id=t3.id,
            key="summary_nonempty",
            score=1.0 if summary and summary != "Summary not available." else 0.0,
            comment="Summary present"
        )
        client.create_feedback(
            run_id=t3.id,
            key="reason_nonempty",
            score=1.0 if reason and "Incomplete" not in reason else 0.0,
            comment="Reason present"
        )

    # Phase 4: completion
    with trace(name="ExecutorCompletion", run_type="tool") as t4:
        t4.add_inputs({"decision": decision, "policy_id": policy_id,"identifier":claim_input.get("identifier")})
        completion = {
            "executor_completed": True,
            "final_decision": decision,
            "policy_id": policy_id,
            "end_time": datetime.now().isoformat(),
            "processing_successful": True
        }
        log_trace(
            claim_id=policy_id,
            step="healthcare_executor_complete",
            output=completion
        )
        t4.add_outputs(completion)

        # Correctness eval if ground truth available
        expected = result.get("expected_decision")
        if expected:
            client.create_feedback(
                run_id=t4.id,
                key="final_decision_correct",
                score=1.0 if decision == expected else 0.0,
                comment=f"Expected={expected}, Got={decision}"
            )

    return {
        "final_decision": decision,
        "policy_id": policy_id,
        "summary": summary,
        "reason": reason,
        "raw_result": result
    }

    # Return consolidated output so the top-level run has a clear output payload


EVAL_TEMPLATES = {
    "decision_eval": """
            You are evaluating the final decision made by an AI agent for a claim.

            Decision: {decision}
            Reason: {decision_reason}
            Summary: {summary}

            Was this decision justified?

            Respond in JSON:
            {{
            "score": <0.0 to 1.0>,
            "decision_justified": <true/false>,
            "justification": "<explanation>"
            }}
            """,
    "reflection_eval": """
            Evaluate the quality of this agent's self-reflection.

            Reflection: {reflection}
            Input: {input}
            Output: {output}

            Was the reflection thoughtful and accurate?

            Respond in JSON:
            {{
            "score": <0.0 to 1.0>,
            "reflection_quality": "<brief comment>",
            "reflection_valid": <true/false>
            }}
            """,
    "final_call_eval": """
            You are reviewing the overall insurance claim workflow.

            Final Summary: {final_summary}
            Agent Results: {agent_results}

            Was the process consistent and complete?

            Respond in JSON:
            {{
            "overall_score": <0.0 to 1.0>,
            "consistent": <true/false>,
            "comment": "<brief final assessment>"
            }}
            """,
}


if __name__ == "__main__":
    # Existing setup
    output_dir = Path("output")
    output_dir.mkdir(parents=True, exist_ok=True)

    function_definitions = """
    verify_document: Verifies the validity of claim documents. Requires policy_id, document, is_valid_claim, and reason.
    check_eligibility: Checks if the claim is eligible based on policy details. Requires policy_id, policy_start, policy_end, and accident_date.
    check_fraud: Checks for fraud indicators in the claim. Requires policy_id, document, claim_amount, and estimated_damage_cost.
    generate_summary: Generates a summary of the claim processing results. Requires policy_id, doc_status, eligibility_status, and fraud_status.
    make_decision: Makes a final decision on the claim. Requires policy_id, doc_status, eligibility_status, fraud_status, and summary.
    """
    functions = [line for line in function_definitions.strip().split('\n') if line]
    print(f"📋 Function definitions loaded: {len(functions)} functions")

    # Your sample inputs (unchanged)
    # Claim Rejected / Not Approved
    claim_input_not_approved_with_notes = {
        "identifier": "TD_001",
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent - submitted_documents_completeness: All required documents have likely been provided, as inferred from the claim status.",
                "document_verification_agent - authenticity_check: Submitted documents are invalid and likely fraudulent, as inferred from the fraudulent claim status.",
                "document_verification_agent - duplicate_document_check: Fraudulent bills or records have been submitted, as inferred from the claim status.",
                "document_verification_agent - provider_details_verification: Provider information matches official records, as inferred from the claim status.",
                "document_verification_agent - service_date_verification: Service dates on documents align with the claimed event, as inferred from the claim status.",
            ],
        },
    }

    claim_input_not_approved = {
        "identifier": "TD_002",
        "policy_id": "HLT-4009",
        "domain": "Major Medical Health Plan",
        "claim_record": {
            "name": "Springfield Medical Center",
            "policy_id": "HLT-4009",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance",
            "accident_date": "2025-05-15",
            "claim_amount": 6700,
            "notes": [],
        },
    }

    # Claim Human Review
    claim_input_human_review = {
        "identifier": "TD_003",
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent: submitted_documents_completeness – All expected documentation appears to be included based on the claim contents.",
                "document_verification_agent: authenticity_check – Several anomalies were detected in the submitted documents, raising concerns about their legitimacy.",
                "document_verification_agent: duplicate_document_check – Some billing entries appear multiple times across documents with inconsistent formatting.",
                "document_verification_agent: provider_details_verification – Provider information aligns with known facility data and license registry records.",
                "document_verification_agent: service_date_verification – Dates of treatment correspond with the reported incident and fall within the policy coverage period."
            ],
        },
    }

    # Claim Passed / Approved
    claim_input_approved = {
        "identifier": "TD_004",
        "policy_id": "HLT-3005",
        "domain": "Major Medical Health Plan",
        "claim_record": {
            "name": "Springfield Medical Center",
            "policy_id": "HLT-3005",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance",
            "accident_date": "2025-05-15",
            "claim_amount": 6700,
            "notes": [
                "document_verification_agent: claim_amount_verification passed – claim amount approved and within coverage limits; validated by insurer.",
                "document_verification_agent: policy_status_verification passed – deductible met and policy status confirmed as current and valid.",
                "document_verification_agent: patient_and_provider_identity_verification passed – patient ID and provider information verified and matched official records.",
                "document_verification_agent: medical_records_completeness_verification passed – medical records complete, well-documented, and in full compliance with standards.",
                "document_verification_agent: service_date_verification passed – services rendered aligned with approved treatment plan; all dates are recent and within policy period.",
                "document_verification_agent: hospital_verification passed – emergency and follow-up visits cross-verified and hospital verified.",
                "document_verification_agent: billing_validation passed – billing and invoice information audit passed and reconciled.",
                "document_verification_agent: documentation_authenticity_verification passed – claim documentation is clear, legible, and digitally signed by the attending physician."
            ],
        },
    }

    claim_input = claim_input_not_approved_with_notes

    print(f"\n📋 === CLAIM INPUT ANALYSIS ===")
    print(f"🆔 Policy ID: {claim_input['policy_id']}")
    print(f"🏥 Domain: {claim_input['domain']}")
    print(f"💰 Claim Amount: ${claim_input['claim_record']['claim_amount']:,}")
    print(f"📝 Notes Count: {len(claim_input['claim_record']['notes'])}")
    print(
        f"📅 Policy Period: {claim_input['claim_record']['policy_start']} to {claim_input['claim_record']['policy_end']}")
    print(f"🗓️ Accident Date: {claim_input['claim_record']['accident_date']}")

    # IMPORTANT: call the decorated executor (creates the top-level LangSmith run)
    result_bundle = run_healthcare_executor(claim_input)

    # You can still print or persist the result_bundle if needed
    print("Executor result:", json.dumps(result_bundle, indent=2))