import json


def get_prompt(policy_id: str | None, claim_record: dict | None, rules: list) -> str:
    return f"""
                You are an AI assistant tasked with validating an insurance claim for the document_verification_agent 
                based on provided claim details and predefined rules.
                
                You will receive:
                1. A claim record with fields: `name`, `policy_id`, `policy_start`, `policy_end`, `claim_type`, 
                `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
                2. Provided Rules for the document_verification_agent for the claim type 'Health Insurance 
                (Major Medical Plan)'.
                
                Your task is to:
                - Validate the claim record against the provided rules for the document_verification_agent.
                - Check the `notes` for explicit rule validations (e.g., "document_verification_agent: description").
                - For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields 
                (e.g., check `accident_date` against `policy_start` and `policy_end`).
                - If any rule fails, the agent's status is "failed". All rules must pass for the status to be "passed".
                - Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
                  - Use 0.9 for rules explicitly validated in notes.
                  - Use 0.6–0.8 for inferred validations based on fields.
                  - Use 0.4–0.5 for rules requiring external data with no explicit note.
                
                Output STRICTLY a JSON result with a single entry for the document_verification_agent:
                - `timestamp`: Use current UTC timestamp
                - `claim_id`: "CLM_{policy_id}"
                - `step`: "document_verification_agent"
                - `status`: "<passed/failed>"
                - `reason`: "<explanation>"
                - `confidence_score`: <float>
                
                **Input Data:**
                
                Claim Record:
                {json.dumps(claim_record, indent=2)}
                
                Rules for document_verification_agent (Claim Type 'Health Insurance (Major Medical Plan)'):
                {json.dumps(rules, indent=2)}
        """
