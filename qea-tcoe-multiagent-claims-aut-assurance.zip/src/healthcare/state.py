from typing import Optional, Literal, Dict, Any, List
from pydantic import BaseModel


class GraphState(BaseModel):
    claim_id: Optional[str] = None
    claim_record: Optional[Dict[str, Any]] = None
    rules: Optional[List[str]] = None
    policy_id: Optional[str] = None
    domain: Optional[str] = None
    document_text: Optional[str] = None
    doc_status: Optional[str] = None
    eligibility_status: Optional[str] = None

    # --- Fraud-related additions/modifications ---
    # fraud_score from the *last* executed fraud sub-agent
    fraud_score: Optional[float] = None
    # Flag to indicate if human review is needed for the *last* executed fraud sub-agent
    human_review_required: Optional[bool] = None

    # This 'fraud_status' was previously for the overall fraud_checker_agent.
    # We might keep it for a final aggregated status if needed, but it's less critical now
    # as individual fraud_scores drive the flow. Let's retain for now but its usage might change.
    fraud_status: Optional[Literal["passed", "failed", "manual_review"]] = None
    eligibility_check_result: Optional[Dict[str, Any]] = None
    document_check_result: Optional[Dict[str, Any]] = None
    # Individual fraud check results (as before, but now directly set by individual agents)
    damage_consistency_check_result: Optional[Dict[str, Any]] = None
    repair_estimate_check_result: Optional[Dict[str, Any]] = None
    duplicate_claim_check_result: Optional[Dict[str, Any]] = None
    incident_veracity_check_result: Optional[Dict[str, Any]] = None

    # Flags to track completion of individual fraud checks (Crucial for supervisor)
    damage_consistency_checked: Optional[bool] = False
    repair_estimate_checked: Optional[bool] = False
    duplicate_claim_checked: Optional[bool] = False
    incident_veracity_checked: Optional[bool] = False
    # --- End Fraud-related additions/modifications ---
    inconsistency_check_result: Optional[Dict[str, Any]] = None
    provider_verification_check_result: Optional[Dict[str, Any]] = None
    service_reasonability_check_result: Optional[Dict[str, Any]] = None

    inconsistency_checked: Optional[bool] = False
    provider_verification_checked: Optional[bool] = False
    service_reasonability_checked: Optional[bool] = False
    # --- End Health Insurance Specific Fraud Check Results and Flags ---

    summary: Optional[str] = None
    summary_confidence: Optional[float] = None
    decision: Optional[str] = None
    reason: Optional[str] = None
    next_step_node: Optional[str] = None
    raw_llm_response: Optional[str] = None
    is_valid_claim: Optional[bool] = None
    estimated_damage_cost: Optional[str] = None
    final_amount: Optional[str] = None


ClaimState = Dict[str, Any]
