import random
from typing import Dict, Any
from src.common_utilities.logger import log_trace
from langsmith import traceable, trace, Client
@traceable(name="check_doc_integrity", run_type="tool")
def check_doc_integrity(claim_id: str, document_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deterministic tool to check document integrity for health insurance claims
    based on content in 'notes' field of the document data.

    Args:
        claim_id: The claim ID for logging purposes
        document_data: Dictionary containing document information

    Returns:
        Dictionary with integrity check result and details
    """
    print(f"🔍 === DOCUMENT INTEGRITY CHECK STARTED ===")
    print(f"🆔 Claim ID: {claim_id}")
    print(f"📄 Document Data Keys: {list(document_data.keys()) if document_data else 'None'}")

    # Log tool invocation
    log_trace(
        claim_id=claim_id,
        step="check_doc_integrity_tool_start",
        output={
            "tool": "check_doc_integrity",
            "claim_id": claim_id,
            "document_data_available": bool(document_data),
            "document_fields": len(document_data) if document_data else 0
        }
    )

    notes = document_data.get("notes")

    if not isinstance(notes, list):
        # Handle missing or malformed notes
        print(f"⚠️ Warning: 'notes' field missing or not a list.")
        status = "unknown"
        reason = "Notes field is missing or in an unexpected format. Unable to determine document integrity."
        confidence = 0.2  # Low confidence due to missing info

        # Log missing notes
        log_trace(
            claim_id=claim_id,
            step="check_doc_integrity_tool_warning",
            output={
                "warning": "Notes field missing or not a list.",
                "claim_id": claim_id,
                "document_data_keys": list(document_data.keys()) if document_data else []
            }
        )
    elif not notes:
        # Handle empty notes list explicitly
        print(f"⚠️ Warning: 'notes' field is an empty list.")
        status = "unknown"
        reason = "No verification notes provided; unable to assess document integrity."
        confidence = 0.2  # Low confidence due to lack of information

        # Log empty notes
        log_trace(
            claim_id=claim_id,
            step="check_doc_integrity_tool_warning",
            output={
                "warning": "Notes field is an empty list.",
                "claim_id": claim_id,
                "document_data_keys": list(document_data.keys()) if document_data else []
            }
        )
    else:
        # Deterministic logic based on notes
        fail_keywords = [
            # Fraud or forgery
            "fraud", "fraudulent", "fake", "forged", "falsified", "doctored", "counterfeit",
            "replica", "duplicate", "not genuine", "not original",
            # Tampering or manipulation
            "tampered", "manipulated", "altered",
            # Verification issues
            "not verified", "unverified", "unauthorized", "missing information", "not provided",
            # Validity and expiration
            "invalid", "expired",
            # Data quality and match issues
            "mismatch", "not matching", "discrepancy", "missing signature", "illegible", "unclear",
            # System or file issues
            "corrupted file",
            # Risk or suspicion
            "blacklisted", "flagged", "suspicious", "suspect", "questionable"
        ]

        fail_detected = any(
            any(keyword in note.lower() for keyword in fail_keywords)
            for note in notes
        )

        positive_keywords = [
            # General validation
            "verified", "authentic", "original", "valid", "genuine", "approved",
            "confirmed", "validated", "accurate", "correct",
            # Match/compliance
            "matched", "matching", "aligned", "consistent", "in order", "in compliance",
            "compliant", "meets criteria", "meets requirements", "acceptable",
            # Clarity
            "clear", "readable", "legible", "complete", "in full", "well-documented",
            # Authority confirmation
            "doctor verified", "hospital verified", "issuer verified", "stamp present",
            "signature present", "digitally signed", "approved by authority",
            # Dates & timelines
            "up to date", "not expired", "recent", "current",
            # Quality assurance
            "qa passed", "quality check passed", "audit passed",
            "reconciled", "cross-verified"
        ]


        """
         COUNT CALCULATION BASED ON NO OF NOTES ADDED IN CLAIM INPUT
         
        # Count negative and positive notes
        negative_notes = [
            note for note in notes
            if any(keyword in note.lower() for keyword in fail_keywords)
        ]

        positive_notes = [
            note for note in notes
            if any(keyword in note.lower() for keyword in positive_keywords)
        ]

        '''
        If there are more positive notes, the score is positive → base confidence moves above 0.5.
        If more negative notes, the score is negative → base confidence moves below 0.5.
        
        More positive notes → higher confidence.
        More negative notes → lower confidence.
        '''

        # Calculate base confidence from both good and bad signals
        total_notes = len(notes) if notes else 1  # avoid divide by zero

        score = (len(positive_notes) - len(negative_notes)) / total_notes
        base_confidence = 0.5 + score * 0.5  # scale to range [0, 1]

        # Clamp between 0.1 and 0.95 (prevents unrealistic values like 0.0 (too low) or 1.0 (too confident))
        base_confidence = max(0.1, min(base_confidence, 0.95))

        # Add moderate randomness ±10%
        # random_offset = random.uniform(-0.1, 0.1)
        random_offset = 0

        # Final confidence, rounded and clamped
        confidence = round(min(max(base_confidence + random_offset, 0.1), 0.99), 2)
        
        """

       # COUNT CALCULATION BASED ON NO OF KEYWORDS PRESENT IN NOTES OF CLAIM INPUT
        def count_keyword_occurrences(text, keywords):
            text_lower = text.lower()
            count = 0
            for kw in keywords:
                count += text_lower.count(kw)
            return count

        # Count total positive and negative keyword occurrences in all notes
        total_positive = sum(count_keyword_occurrences(note, positive_keywords) for note in notes)
        total_negative = sum(count_keyword_occurrences(note, fail_keywords) for note in notes)

        total_keywords = total_positive + total_negative if (total_positive + total_negative) > 0 else 1  # avoid div by zero

        score = (total_positive - total_negative) / total_keywords  # range [-1, 1]
        confidence = 0.5 + score * 0.5  # map to [0, 1]
        confidence = max(0.0, min(confidence, 1.0))
        confidence_rounded = round(confidence, 2)
        confidence = confidence_rounded
        print(f"Total positive keyword occurrences: {total_positive}")
        print(f"Total negative keyword occurrences: {total_negative}")
        print(f"Confidence (0 to 1): {confidence}")

    if confidence >= 0.75:
        status = "passed"
        reason = "No integrity issues found in document verification notes."
        # confidence = round(random.uniform(0.8, 0.95), 2)
        confidence = confidence
        print(f"✅ INTEGRITY CHECK: PASSED")

    else :
        status = "failed"
        reason = "Document integrity concerns detected based on verification notes (e.g., invalid or fraudulent documents)."
        # confidence = round(random.uniform(0.3, 0.6), 2)
        confidence = confidence
        print(f"❌ INTEGRITY CHECK: FAILED")


    print(f"📊 Integrity Check Result:")
    print(f"   Status: {status}")
    print(f"   Confidence: {confidence}")
    print(f"   Reason: {reason}")

    result = {
        "integrity_status": status,
        "integrity_reason": reason,
        "integrity_confidence": confidence,
        "tool_used": "check_doc_integrity",
        "claim_id": claim_id
    }

    # Log final result
    log_trace(
        claim_id=claim_id,
        step="check_doc_integrity_tool_result",
        output=result
    )

    print(f"🏁 Document Integrity Check Completed")
    print(f"🔍 === DOCUMENT INTEGRITY CHECK FINISHED ===\n")

    return result

