from typing import Dict, Any
from src.common_utilities.logger import log_trace
from src.common_layers.llm_layer.llm_manager import LLMManager
import os
import json
from langsmith import traceable

@traceable(name="integrity_investigator", run_type="tool")
def integrity_investigator(claim_id: str, integrity_failure_details: str,document_tool_result:str) -> Dict[str, Any]:
    """
    Tool to investigate integrity failures and generate plausible reasons using LLM.
    """
    print(f"🔍 === INTEGRITY INVESTIGATOR STARTED ===")
    print(f"🆔 Claim ID: {claim_id}")
    print(f"📄 Failure Details: {integrity_failure_details}")
    print(f"Previous tool output : {document_tool_result}")
    # Log invocation
    log_trace(
        claim_id=claim_id,
        step="integrity_investigator_tool_start",
        output={
            "tool": "integrity_investigator",
            "claim_id": claim_id,
            "failure_details": integrity_failure_details
        }
    )

    # Fixed list of possible integrity failure reasons (your original list)
    possible_reasons = [
        "Digital signature verification failed - document may have been tampered with after creation",
        "Metadata inconsistencies detected - document creation date does not match claimed service date",
        "Document format anomalies found - suspicious compression or encoding patterns detected",
        "Cross-reference check failed - provider information does not match registered healthcare database",
        "Watermark or security features missing or invalid in submitted documentation",
        "Document structure analysis indicates potential template manipulation or field alteration",
        "Timestamp verification failed - document shows signs of backdating or future dating",
        "Electronic health record integration check failed - inconsistent with patient medical history",
        "Provider license validation failed - submitting provider not authorized for claimed services",
        "Document quality assessment indicates potential photocopying or scanning artifacts suggesting forgery"
    ]

    # Create LLM prompt
    prompt = f"""
You are a document integrity investigator. A document integrity check has failed with the following failure details:

"{integrity_failure_details}"

Additionally, here is relevant contextual information from a document analysis tool:
"{document_tool_result}"

You have a list of possible technical reasons for failure. Your task is:
1. Identify which reason from the list below best explains the failure (semantic match).
2. Give a risk level: "Medium", "High", or "Critical" depending on severity.
3. Provide a risk score between 0.1 and 0.95 based on how well the combined information from the failure details and the document tool output aligns with the chosen reason.
4. Suggest one relevant additional check from the given list.

Possible Reasons:
{json.dumps(possible_reasons, indent=2)}

Output your response in this exact JSON format:
Respond with ONLY a JSON object in this exact format:
DO NOT ADD '''json or anything else before or after the json object.
{{
  "primary_concern": "<most relevant reason>",
  "risk_level": "<Medium|High|Critical>",
  "investigation_risk_score": 0.0,
  "recommended_action": "Manual review required - escalate to document forensics team",
  "additional_checks_needed": "<choose one: Provider background verification | Patient medical history cross-reference | Digital forensics analysis | Third-party document authentication | Regulatory compliance check>"
}}
"""

    print("🤖 Calling LLM to analyze failure details...")

    # Call Azure LLM using LLMManager
    client = LLMManager().get_non_chat_client()
    response = client.chat.completions.create(
        model=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    '''
    A higher risk score (closer to 0.95) means the model is more certain that the identified reason really explains the failure.
    A lower risk score (closer to 0.1) means there is less certainty or weaker alignment between the failure details and the reason.
    '''

    response_content = response.choices[0].message.content.strip()

    print(f"🧠 LLM Output: {response_content}")

    try:
        investigation_details = json.loads(response_content)
    except json.JSONDecodeError as e:
        print(f"❌ Failed to parse LLM response: {e}")
        investigation_details = {
            "primary_concern": "Unable to determine reason due to LLM response error",
            "risk_level": "Medium",
            "investigation_risk_score": 0.6,
            "recommended_action": "Manual review required - escalate to document forensics team",
            "additional_checks_needed": "Digital forensics analysis"
        }

    # Assemble result
    result = {
        "investigation_reason": investigation_details.get("primary_concern"),
        "investigation_details": investigation_details,
        "tool_used": "integrity_investigator",
        "claim_id": claim_id,
        "status": "investigation_complete"
    }

    # Log result
    log_trace(
        claim_id=claim_id,
        step="integrity_investigator_tool_result",
        output=result
    )

    print(f"✅ Investigation Completed")
    print(f"🔍 === INTEGRITY INVESTIGATOR FINISHED ===\n")

    return result
