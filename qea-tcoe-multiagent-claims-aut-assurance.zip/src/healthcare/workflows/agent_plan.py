import json
from langchain_core.messages import HumanMessage
from src.common_layers.llm_layer.llm_manager import LLMManager

AGENT_BEHAVIOR_PROMPT = """
You are an evaluation assistant. Assess whether the behavior of the agent named "{agent_name}" is correct and compliant with its SME definition.

[BEGIN DATA]
************
AGENT_NAME: {agent_name}
************
AGENT_INPUT: {agent_input}
************
AGENT_OUTPUT: {agent_output}
************
AGENT_SME_DEFINITION:
{agent_sme_definition}
************
[END DATA]

Evaluate the following:
- Did the agent stay within its scope?
- Did it perform all required responsibilities?
- Did it avoid forbidden actions?
- Was the output appropriate given the input and SME definition?

Return STRICT JSON ONLY:
{{
  "agent_name": "{agent_name}",
  "compliance_status": "passed" | "partially passed" | "failed",
  "reason": "<brief explanation>",
  "score_0_to_100": <number>
}}
"""

AGENT_SME_DEFINITIONS = {
    "DocumentVerifierAgent": """
    - Must check for required documents (discharge summaries, bills, test reports).
    - Must verify authenticity, readability, and consistency with claim details.
    - Must flag missing, unclear, or mismatched info.
    - Must NOT decide coverage, evaluate fraud, approve/reject claims, alter details, or summarize.
    """,
    "EligibilityAgent": """
    - Must verify policy activity on treatment date.
    - Must check if treatment is covered and not excluded.
    - Must flag expired/invalid policies.
    - Must NOT approve claims, evaluate fraud, verify documents, or make final decisions.
    """,
    "FraudCheckAgent": """
    - Must detect duplicate claims, diagnosis-bill mismatches, unlicensed providers, and abnormal costs.
    - Must flag suspicious issues.
    - Must NOT make final decisions, approve/reject claims, or handle document/eligibility checks.
    """,
    "SummarizerAgent": """
    - Must compile results from other agents.
    - Must summarize what passed/failed.
    - Must NOT invent or alter information.
    """,
    "DecisionMakerAgent": """
    - Must use the summary and rules to decide outcomes.
    - Must approve if all checks pass.
    - Must reject if documents are missing, policy invalid, or fraud confirmed.
    - Must send to manual review if results are unclear.
    """
}

def evaluate_single_agent(agent_name: str, agent_input: str, agent_output: str) -> dict:
    if agent_name not in AGENT_SME_DEFINITIONS:
        raise ValueError(f"Unknown agent: {agent_name}")

    llm = LLMManager().get_llm()

    prompt = AGENT_BEHAVIOR_PROMPT.format(
        agent_name=agent_name,
        agent_input=agent_input,
        agent_output=agent_output,
        agent_sme_definition=AGENT_SME_DEFINITIONS[agent_name].strip()
    )

    response = llm.invoke(
        [HumanMessage(content=prompt)],
        config={"run_name": f"{agent_name}Evaluation"}
    )

    content = response.content.strip().replace("```json", "").replace("```", "")
    try:
        parsed = json.loads(content)
    except Exception as e:
        parsed = {
            "agent_name": agent_name,
            "compliance_status": "failed",
            "reason": f"Parsing failed: {e}",
            "score_0_to_100": 0
        }

    return parsed

result = evaluate_single_agent(
    agent_name="FraudCheckAgent",
    agent_input='''
         {
  "policy_id": "HLT-2002",
  "domain": "Health Insurance (Major Medical Plan)",
  "claim_record": {
    "name": "Valid Medical",
    "policy_id": "HLT-2002",
    "policy_start": "2025-01-01",
    "policy_end": "2025-12-31",
    "claim_type": "Health Insurance (Major Medical Plan)",
    "accident_date": "2025-05-15",
    "claim_amount": 12000,
    "notes": [
      "document_verification_agent: submitted_documents_completeness – All expected documentation appears to be included based on the claim contents.",
      "document_verification_agent: authenticity_check – Several anomalies were detected in the submitted documents, raising concerns about their legitimacy.",
      "document_verification_agent: duplicate_document_check – Some billing entries appear multiple times across documents with inconsistent formatting.",
      "document_verification_agent: provider_details_verification – Provider information aligns with known facility data and license registry records.",
      "document_verification_agent: service_date_verification – Dates of treatment correspond with the reported incident and fall within the policy coverage period."
    ]
  },
  "document_check_result": "\n{\n    \"timestamp\": \"2025-06-26T16:45:00.00\",\n    \"claim_id\": \"HLT-2002\",\n    \"step\": \"document_verification\",\n    \"status\": \"failed\",\n    \"reason\": \"The authenticity_check and duplicate_document_check rules failed as noted in the claim's validation notes. Document integrity was also highlighted as problematic due to anomalies in authenticity. Although provider details and service dates were verified successfully, multiple discrepancies in critical rules make the overall status fail.\",\n    \"confidence\": 0.65\n}\n",
  "__path__": [
    "DocumentVerifier",
    "FraudDetector"
  ]
}
    ''',
    agent_output='''
    {
  "policy_id": "HLT-2002",
  "domain": "Health Insurance (Major Medical Plan)",
  "claim_record": {
    "name": "Valid Medical",
    "policy_id": "HLT-2002",
    "policy_start": "2025-01-01",
    "policy_end": "2025-12-31",
    "claim_type": "Health Insurance (Major Medical Plan)",
    "accident_date": "2025-05-15",
    "claim_amount": 12000,
    "notes": [
      "document_verification_agent: submitted_documents_completeness – All expected documentation appears to be included based on the claim contents.",
      "document_verification_agent: authenticity_check – Several anomalies were detected in the submitted documents, raising concerns about their legitimacy.",
      "document_verification_agent: duplicate_document_check – Some billing entries appear multiple times across documents with inconsistent formatting.",
      "document_verification_agent: provider_details_verification – Provider information aligns with known facility data and license registry records.",
      "document_verification_agent: service_date_verification – Dates of treatment correspond with the reported incident and fall within the policy coverage period."
    ]
  },
  "document_check_result": "\n{\n    \"timestamp\": \"2025-06-26T16:45:00.00\",\n    \"claim_id\": \"HLT-2002\",\n    \"step\": \"document_verification\",\n    \"status\": \"failed\",\n    \"reason\": \"The authenticity_check and duplicate_document_check rules failed as noted in the claim's validation notes. Document integrity was also highlighted as problematic due to anomalies in authenticity. Although provider details and service dates were verified successfully, multiple discrepancies in critical rules make the overall status fail.\",\n    \"confidence\": 0.65\n}\n",
  "__path__": [
    "DocumentVerifier",
    "FraudDetector"
  ],
  "fraud_detection_results": {
    "duplicate_claim": {
      "duplicate_claim_check_result": {
        "timestamp": "2025-10-16T18:02:34.464024",
        "claim_id": "CLM_HLT-2002",
        "step": "fraud_checker_agent (Rule: duplicate_claim_review)",
        "status": "failed",
        "reason": "The new claim is identical to a past claim in terms of accident date, claim amount, policy details, and service type. There is also evidence of repeated billing entries and a high similarity flagged by previous reviews.",
        "fraud_score": 90,
        "human_review_required": false
      },
      "fraud_score": 90,
      "human_review_required": false
    },
    "inconsistency_detection": {
      "inconsistency_check_result": {
        "timestamp": "2025-10-16T18:02:42.062611",
        "claim_id": "CLM_HLT-2002",
        "step": "fraud_checker_agent (Rule: inconsistency_detection)",
        "status": "failed",
        "reason": "There are significant discrepancies in the claim: the claimed amount ($12,000) does not match the billed amount ($6,700), and the physical therapy service date (2025-05-25) was not listed in the original claim submission. Additionally, no documentation was provided for medical transportation despite the high claimed amount. While the accident date (2025-05-15) aligns with the policy coverage, treatment started five days later (2025-05-20), which raises further concerns.",
        "fraud_score": 85,
        "human_review_required": false
      },
      "fraud_score": 85,
      "human_review_required": false
    },
    "provider_verification": {
      "provider_verification_check_result": {
        "timestamp": "2025-10-16T18:02:46.517231",
        "claim_id": "CLM_HLT-2002",
        "step": "fraud_checker_agent (Rule: provider_verification)",
        "status": "passed",
        "reason": "The provider information aligns with a known valid provider in the list (Dr. Angela Roberts, MD, Springfield Medical Center). NPI number, license number, and other details match.",
        "fraud_score": 0,
        "human_review_required": false
      },
      "fraud_score": 0,
      "human_review_required": false
    },
    "service_reasonability": {
      "service_reasonability_check_result": {
        "timestamp": "2025-10-16T18:02:51.311112",
        "claim_id": "CLM_HLT-2002",
        "step": "fraud_checker_agent (Rule: service_reasonability_check)",
        "status": "manual_review",
        "reason": "The discrepancy between the billed amount ($6,700) and the claimed amount ($12,000) is unexplained, and certain services (e.g., physical therapy session) were not originally listed in the claim submission. Additionally, there is no documentation for medical transportation despite the high claimed amount. However, the documented services align with standard treatment for the reported condition.",
        "fraud_score": 50,
        "human_review_required": true
      },
      "fraud_score": 50,
      "human_review_required": true
    }
  }
}
    '''
)

print(result["compliance_status"])
print(result["reason"])
print(result["score_0_to_100"])
